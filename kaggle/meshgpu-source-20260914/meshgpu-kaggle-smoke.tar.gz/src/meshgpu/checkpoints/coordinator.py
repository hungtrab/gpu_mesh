"""
Checkpoint coordinator — snapshot, commit and restore logic.
Follows the commit protocol in plan.md §10.2:
  1. All stages snapshot at same logical step.
  2. Upload shards to new prefix.
  3. Controller verifies shard count/hash.
  4. Write manifest; update committed pointer atomically.
  5. Only committed manifests are used for resume.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from pathlib import Path

import torch

log = logging.getLogger(__name__)


class CheckpointCoordinator:
    def __init__(self, root: str | Path) -> None:
        self._root = Path(root).resolve()
        self._root.mkdir(parents=True, exist_ok=True)
        self._committed: str | None = None  # path to committed manifest
        self._committed_checkpoint_id: str | None = None
        self._committed_history: dict[str, str] = {}
        self._pointer_file = self._root / "committed.json"
        self._refresh_commit_index()

    def _refresh_commit_index(self) -> None:
        """Read one atomically published index, including commits by other writers."""
        self._committed = None
        self._committed_checkpoint_id = None
        self._committed_history = {}
        if self._pointer_file.exists():
            try:
                data = json.loads(self._pointer_file.read_text())
                if isinstance(data, dict):
                    self._committed = data.get("path")
                    self._committed_checkpoint_id = data.get("checkpoint_id")
                    entries = data.get("checkpoints")
                    if isinstance(entries, list):
                        for entry in entries:
                            if not isinstance(entry, dict):
                                continue
                            checkpoint_id = entry.get("checkpoint_id")
                            path = entry.get("path")
                            if not isinstance(checkpoint_id, str) or not checkpoint_id:
                                continue
                            if not isinstance(path, str) or not path:
                                continue
                            try:
                                resolved = self._resolve_rooted_path(path)
                            except ValueError:
                                continue
                            if resolved.name == "manifest.json":
                                self._committed_history[checkpoint_id] = path
                    # Pointers written by older versions contain only the
                    # current checkpoint.  Keep that checkpoint recoverable
                    # while newer saves build the durable history list.
                    if (
                        isinstance(self._committed_checkpoint_id, str)
                        and isinstance(self._committed, str)
                    ):
                        current_resolved: Path | None
                        try:
                            current_resolved = self._resolve_rooted_path(self._committed)
                        except ValueError:
                            current_resolved = None
                        if (
                            current_resolved is not None
                            and current_resolved.name == "manifest.json"
                        ):
                            self._committed_history.setdefault(
                                self._committed_checkpoint_id,
                                self._committed,
                            )
            except (OSError, json.JSONDecodeError, TypeError):
                log.warning("ignoring malformed checkpoint pointer: %s", self._pointer_file)

    # ------------------------------------------------------------------
    # Snapshot
    # ------------------------------------------------------------------

    def save(
        self,
        *,
        job_id: str,
        global_step: int,
        model_states: list[dict],    # one state_dict per stage
        optimizer_states: list[dict],
        scheduler_state: dict | None = None,
        scheduler_states: list[dict] | None = None,
        scaler_state: dict | None = None,
        rng_states: list[dict] | None = None,
        data_cursor: dict | None = None,
        placement: dict | None = None,
        software_profile: dict | None = None,
    ) -> str:
        """Save checkpoint; return checkpoint_id on commit."""
        if not isinstance(job_id, str) or not job_id.strip():
            raise ValueError("job_id must be a non-empty string")
        if (
            isinstance(global_step, bool)
            or not isinstance(global_step, int)
            or global_step < 0
        ):
            raise ValueError("global_step must be a non-negative integer")
        if not model_states:
            raise ValueError("checkpoint must contain at least one stage")
        if not all(isinstance(state, dict) for state in model_states):
            raise TypeError("each model state must be a state_dict mapping")
        if not all(isinstance(state, dict) for state in optimizer_states):
            raise TypeError("each optimizer state must be a mapping")
        if len(model_states) != len(optimizer_states):
            raise ValueError(
                "model_states and optimizer_states must have the same number of stages"
            )
        if scheduler_state is not None and scheduler_states is not None:
            raise ValueError(
                "provide scheduler_state or scheduler_states, not both"
            )
        if scheduler_states is not None and len(scheduler_states) != len(model_states):
            raise ValueError("scheduler_states must contain one state per stage")
        if scheduler_states is not None and not all(
            isinstance(state, dict) for state in scheduler_states
        ):
            raise TypeError("each scheduler state must be a mapping")
        if scheduler_state is not None and not isinstance(scheduler_state, dict):
            raise TypeError("scheduler_state must be a mapping")
        if scaler_state is not None and not isinstance(scaler_state, dict):
            raise TypeError("scaler_state must be a mapping")
        if rng_states is not None:
            if len(rng_states) != len(model_states):
                raise ValueError("rng_states must contain one state per stage")
            if not all(isinstance(state, dict) for state in rng_states):
                raise TypeError("each RNG state must be a mapping")
        if data_cursor is not None and not isinstance(data_cursor, dict):
            raise TypeError("data_cursor must be a mapping")
        if placement is not None and not isinstance(placement, dict):
            raise TypeError("placement must be a mapping")
        if software_profile is not None and not isinstance(software_profile, dict):
            raise TypeError("software_profile must be a mapping")

        ckpt_id = f"ckpt_{global_step:08d}_{uuid.uuid4().hex[:8]}"
        ckpt_dir = self._root / ckpt_id
        ckpt_dir.mkdir(parents=True)

        shard_manifest: list[dict] = []

        for i, (ms, os_) in enumerate(zip(model_states, optimizer_states)):
            shard_path = ckpt_dir / f"stage_{i}.pt"
            payload = {
                "model": ms,
                "optimizer": os_,
                "global_step": global_step,
            }
            if scheduler_states is not None:
                payload["scheduler"] = scheduler_states[i]
            elif scheduler_state is not None:
                # Backwards-compatible form for callers with one shared
                # scheduler state.
                payload["scheduler"] = scheduler_state
            if scaler_state is not None:
                payload["scaler"] = scaler_state
            if rng_states is not None:
                payload["rng"] = rng_states[i]
            if data_cursor is not None:
                payload["data_cursor"] = data_cursor

            _atomic_torch_save(payload, shard_path)
            sha = _sha256_file(shard_path)
            shard_manifest.append({
                "stage": i,
                "path": str(shard_path.relative_to(self._root)),
                "sha256": sha,
                "byte_length": shard_path.stat().st_size,
            })

        manifest = {
            "checkpoint_id": ckpt_id,
            "job_id": job_id,
            "global_step": global_step,
            "shards": shard_manifest,
            "placement": placement,
            "software_profile": software_profile,
            "saved_at": time.time(),
        }
        manifest_path = ckpt_dir / "manifest.json"
        _atomic_write_text(manifest_path, json.dumps(manifest, indent=2))
        _fsync_directory(ckpt_dir)

        # Atomic commit: publish the new checkpoint ID in the same durable
        # pointer that records the older committed IDs.  A checkpoint whose
        # manifest exists but is absent from this index is not resumable.
        committed_path = str(manifest_path.relative_to(self._root))
        # flock covers the entire read/merge/publish transaction across
        # coordinator instances, threads and processes on this POSIX runtime.
        import fcntl

        with (self._root / '.commit.lock').open('a+b') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                self._publish_checkpoint(ckpt_id, committed_path)
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        log.info("checkpoint committed: %s (step=%d)", ckpt_id, global_step)
        return ckpt_id

    def _publish_checkpoint(self, ckpt_id: str, committed_path: str) -> None:
        """Merge the current on-disk index while holding the commit lock."""
        current = CheckpointCoordinator(self._root)
        if self._pointer_file.exists() and current.load_latest() is None:
            raise ValueError("cannot overwrite an invalid checkpoint commit index")
        tmp = self._pointer_file.with_name(
            f"{self._pointer_file.name}.{uuid.uuid4().hex}.tmp"
        )
        committed_history = dict(current._committed_history)
        committed_history[ckpt_id] = committed_path
        pointer_payload = {
            "path": committed_path,
            "checkpoint_id": ckpt_id,
            "checkpoints": [
                {"checkpoint_id": checkpoint_id, "path": path}
                for checkpoint_id, path in committed_history.items()
            ],
        }
        try:
            tmp.write_text(json.dumps(pointer_payload))
            with tmp.open("rb") as pointer:
                os.fsync(pointer.fileno())
            os.replace(tmp, self._pointer_file)
        except Exception:
            tmp.unlink(missing_ok=True)
            raise
        _fsync_directory(self._root)
        self._committed = committed_path
        self._committed_checkpoint_id = ckpt_id
        self._committed_history = committed_history

    # ------------------------------------------------------------------
    # Restore
    # ------------------------------------------------------------------

    def load_latest(self) -> dict | None:
        """Load the committed checkpoint manifest, or None if none exists."""
        p = self._committed_manifest_path()
        if p is None:
            return None
        if not p.exists():
            log.warning("committed checkpoint manifest missing: %s", p)
            return None
        try:
            manifest = json.loads(p.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            log.warning("committed checkpoint manifest unreadable: %s", exc)
            return None
        if not isinstance(manifest, dict):
            log.warning("committed checkpoint manifest is not an object: %s", p)
            return None
        if (
            self._committed_checkpoint_id is not None
            and manifest.get("checkpoint_id") != self._committed_checkpoint_id
        ):
            log.warning("checkpoint pointer/id mismatch: %s", p)
            return None
        return manifest

    def load_manifest(self, checkpoint_id: str) -> dict:
        """Load a specific checkpoint manifest by its immutable ID.

        Explicit recovery and export operations may target an older checkpoint
        than the current ``committed.json`` pointer.  The durable pointer
        history authorizes the ID; ``load_stage`` then verifies each referenced
        shard before returning its payload.
        """
        checkpoint_dir = self._checkpoint_dir(checkpoint_id)
        # Other processes may have committed since this instance was created.
        current = CheckpointCoordinator(self._root)
        committed_path = current._committed_history.get(checkpoint_id)
        if committed_path is None:
            raise ValueError(f"checkpoint is not committed: {checkpoint_id!r}")
        manifest_path = checkpoint_dir / "manifest.json"
        try:
            indexed_path = self._resolve_rooted_path(committed_path)
        except ValueError as exc:
            raise ValueError(
                f"checkpoint pointer has an invalid path for {checkpoint_id!r}"
            ) from exc
        if indexed_path != manifest_path:
            raise ValueError(
                f"checkpoint pointer path does not match ID: {checkpoint_id!r}"
            )
        if not manifest_path.exists():
            raise FileNotFoundError(f"checkpoint manifest not found: {manifest_path}")
        try:
            manifest = json.loads(manifest_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"checkpoint manifest is unreadable: {manifest_path}") from exc
        if not isinstance(manifest, dict):
            raise ValueError(f"checkpoint manifest must be an object: {manifest_path}")
        if manifest.get("checkpoint_id") != checkpoint_id:
            raise ValueError(
                f"checkpoint manifest/id mismatch: requested {checkpoint_id!r}, "
                f"manifest contains {manifest.get('checkpoint_id')!r}"
            )
        return manifest

    def load_stage(self, checkpoint_id: str, stage: int) -> dict:
        """Load saved payload for one stage shard."""
        if stage < 0:
            raise ValueError("stage must be non-negative")
        manifest = self.load_manifest(checkpoint_id)
        shards = manifest.get("shards")
        if not isinstance(shards, list):
            raise ValueError(
                f"checkpoint manifest has invalid shards: {checkpoint_id}"
            )
        shard = next(
            (
                entry
                for entry in shards
                if isinstance(entry, dict) and entry.get("stage") == stage
            ),
            None,
        )
        if shard is None:
            raise FileNotFoundError(f"stage {stage} not found in checkpoint {checkpoint_id}")
        shard_path_value = shard.get("path")
        if not isinstance(shard_path_value, str) or not shard_path_value:
            raise ValueError(f"checkpoint shard has invalid path: {shard!r}")
        shard_path = self._resolve_rooted_path(shard_path_value)
        if not shard_path.exists():
            raise FileNotFoundError(f"shard not found: {shard_path}")
        expected_size = shard.get("byte_length")
        if not isinstance(expected_size, int) or expected_size < 0:
            raise ValueError(f"checkpoint shard has invalid byte_length: {shard!r}")
        if shard_path.stat().st_size != expected_size:
            raise ValueError(f"checkpoint shard size mismatch: {shard_path}")
        actual_sha = _sha256_file(shard_path)
        expected_sha = shard.get("sha256")
        if not isinstance(expected_sha, str) or actual_sha != expected_sha:
            raise ValueError(
                f"checkpoint shard hash mismatch: expected {expected_sha}, "
                f"got {actual_sha}"
            )
        # Checkpoints may have been written by a different GPU host.  Loading
        # onto CPU first avoids requiring the original CUDA device ordinal;
        # model/optimizer ``load_state_dict`` then moves values to live params.
        payload = torch.load(shard_path, map_location="cpu", weights_only=False)
        if not isinstance(payload, dict):
            raise ValueError(f"checkpoint stage payload is not a mapping: {shard_path}")
        if not isinstance(payload.get("model"), dict):
            raise ValueError(f"checkpoint stage payload has no model state: {shard_path}")
        if not isinstance(payload.get("optimizer"), dict):
            raise ValueError(
                f"checkpoint stage payload has no optimizer state: {shard_path}"
            )
        saved_step = payload.get("global_step")
        if (
            isinstance(saved_step, bool)
            or not isinstance(saved_step, int)
            or saved_step < 0
        ):
            raise ValueError(f"checkpoint stage payload has invalid global_step: {shard_path}")
        return payload

    def verify(self, checkpoint_id: str) -> list[str]:
        """Return list of corrupt or missing shards."""
        manifest_path = self._checkpoint_dir(checkpoint_id) / "manifest.json"
        if not manifest_path.exists():
            return [f"manifest missing for {checkpoint_id}"]
        try:
            manifest = json.loads(manifest_path.read_text())
        except (OSError, json.JSONDecodeError):
            return [f"manifest unreadable for {checkpoint_id}"]
        if not isinstance(manifest, dict) or manifest.get("checkpoint_id") != checkpoint_id:
            return [f"manifest invalid for {checkpoint_id}"]
        shards = manifest.get("shards")
        if not isinstance(shards, list):
            return [f"manifest shards invalid for {checkpoint_id}"]
        bad = []
        for shard in shards:
            if not isinstance(shard, dict):
                bad.append("<invalid shard entry>")
                continue
            shard_path_value = shard.get("path")
            expected_sha = shard.get("sha256")
            if not isinstance(shard_path_value, str) or not isinstance(expected_sha, str):
                bad.append(str(shard_path_value))
                continue
            try:
                p = self._resolve_rooted_path(shard_path_value)
            except ValueError:
                bad.append(shard_path_value)
                continue
            if not p.exists():
                bad.append(shard_path_value)
                continue
            expected_size = shard.get("byte_length")
            if not isinstance(expected_size, int) or p.stat().st_size != expected_size:
                bad.append(shard_path_value)
                continue
            if _sha256_file(p) != expected_sha:
                bad.append(shard_path_value)
        return bad

    @property
    def committed_id(self) -> str | None:
        if self._committed_manifest_path() is None:
            return None
        return self._committed_checkpoint_id

    def _checkpoint_dir(self, checkpoint_id: str) -> Path:
        """Resolve a generated checkpoint ID without allowing path traversal."""
        if (
            not checkpoint_id
            or checkpoint_id in {".", ".."}
            or Path(checkpoint_id).name != checkpoint_id
        ):
            raise ValueError(f"invalid checkpoint id: {checkpoint_id!r}")
        return self._root / checkpoint_id

    def _resolve_rooted_path(self, relative_path: str) -> Path:
        candidate = Path(relative_path)
        if candidate.is_absolute() or ".." in candidate.parts:
            raise ValueError(f"checkpoint path escapes root: {relative_path!r}")
        root = self._root.resolve()
        resolved = (root / candidate).resolve()
        try:
            resolved.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"checkpoint path escapes root: {relative_path!r}") from exc
        return resolved

    def _committed_manifest_path(self) -> Path | None:
        """Resolve the committed pointer without permitting root escape."""
        self._refresh_commit_index()
        if not self._committed or not isinstance(self._committed, str):
            return None
        candidate = Path(self._committed)
        if candidate.is_absolute():
            resolved = candidate.resolve()
            root = self._root.resolve()
            try:
                resolved.relative_to(root)
            except ValueError:
                log.warning("checkpoint pointer escapes root: %s", candidate)
                return None
        else:
            try:
                resolved = self._resolve_rooted_path(self._committed)
            except ValueError as exc:
                log.warning("invalid checkpoint pointer: %s", exc)
                return None
        if resolved.name != "manifest.json":
            log.warning("checkpoint pointer does not reference manifest.json: %s", resolved)
            return None
        return resolved


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(8 * 1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def _atomic_torch_save(payload: dict, destination: Path) -> None:
    """Write a checkpoint shard without exposing a partial pickle."""
    temporary = destination.with_name(
        f".{destination.name}.{uuid.uuid4().hex}.tmp"
    )
    try:
        torch.save(payload, temporary)
        with temporary.open("rb") as written:
            os.fsync(written.fileno())
        os.replace(temporary, destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _atomic_write_text(destination: Path, contents: str) -> None:
    """Write a manifest atomically and flush it before publication."""
    temporary = destination.with_name(
        f".{destination.name}.{uuid.uuid4().hex}.tmp"
    )
    try:
        temporary.write_text(contents)
        with temporary.open("rb") as written:
            os.fsync(written.fileno())
        os.replace(temporary, destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _fsync_directory(directory: Path) -> None:
    """Flush directory metadata after atomic renames on POSIX filesystems."""
    try:
        fd = os.open(directory, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
