"""Import and load Qwen3 dense Hugging Face checkpoints.

Unlike the legacy Llama importer, this adapter never translates Qwen weights
into MeshGPU's handwritten model.  It stores compact stage-local state dicts
whose modules are reconstructed from the official ``Qwen3Config`` and
``Qwen3DecoderLayer`` classes.
"""
from __future__ import annotations

import json
import logging
import uuid
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import torch

from meshgpu.artifacts.hf_import import (
    _atomic_torch_save,
    _atomic_write_text,
    _find_safetensor_root,
    _resolve_artifact_path,
    _SafeTensorSource,
    _save_tokenizer_atomic,
    _sha256_file,
    _state_for_requested_range,
    _validate_requested_ranges,
)
from meshgpu.artifacts.manifest import ManifestMeta, ModelManifest, ShardEntry
from meshgpu.models.qwen3_hf import (
    Qwen3Stage,
    qwen3_config_from_dict,
    qwen3_config_to_dict,
)

log = logging.getLogger(__name__)


def _require_transformers() -> Any:
    try:
        import transformers
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise RuntimeError(
            "Qwen3 import requires Transformers; install `meshgpu[hf]`"
        ) from exc
    if not hasattr(transformers, "Qwen3Config"):
        raise RuntimeError(
            "installed Transformers does not provide Qwen3; "
            "use a recent `meshgpu[hf]` environment"
        )
    return transformers


def split_layers(n_layers: int, n_stages: int) -> list[tuple[int, int]]:
    """Return contiguous layer ranges, putting remainders at the front."""
    if n_layers < 1 or n_stages < 1:
        raise ValueError("n_layers and n_stages must be positive")
    if n_stages > n_layers:
        raise ValueError(f"n_stages={n_stages} exceeds n_layers={n_layers}")
    base, remainder = divmod(n_layers, n_stages)
    ranges: list[tuple[int, int]] = []
    start = 0
    for index in range(n_stages):
        end = start + base + (1 if index < remainder else 0)
        ranges.append((start, end))
        start = end
    return ranges


def remap_qwen_keys(
    full_state: dict[str, torch.Tensor],
    layer_start: int,
    layer_end: int,
    *,
    is_first: bool,
    is_last: bool,
    tie_word_embeddings: bool = False,
) -> dict[str, torch.Tensor]:
    """Extract one stage and convert global HF layer names to local names."""
    stage_state: dict[str, torch.Tensor] = {}
    for global_index in range(layer_start, layer_end):
        source_prefix = f"model.layers.{global_index}."
        local_prefix = f"layers.{global_index - layer_start}."
        for key, value in full_state.items():
            if key.startswith(source_prefix):
                stage_state[local_prefix + key[len(source_prefix):]] = value

    if is_first and "model.embed_tokens.weight" in full_state:
        stage_state["embed_tokens.weight"] = full_state["model.embed_tokens.weight"]
    if is_last:
        if "model.norm.weight" in full_state:
            stage_state["norm.weight"] = full_state["model.norm.weight"]
        if "lm_head.weight" in full_state:
            stage_state["lm_head.weight"] = full_state["lm_head.weight"]
        elif tie_word_embeddings and "model.embed_tokens.weight" in full_state:
            stage_state["lm_head.weight"] = full_state["model.embed_tokens.weight"]
    return stage_state


def _stage_from_safetensors(
    source: _SafeTensorSource,
    layer_start: int,
    layer_end: int,
    *,
    is_first: bool,
    is_last: bool,
    tie_word_embeddings: bool,
    dtype: torch.dtype,
) -> dict[str, torch.Tensor]:
    """Read only tensors owned by one Qwen stage from an indexed checkpoint."""
    stage_state: dict[str, torch.Tensor] = {}
    keys = sorted(source.keys())
    for global_index in range(layer_start, layer_end):
        source_prefix = f"model.layers.{global_index}."
        local_prefix = f"layers.{global_index - layer_start}."
        for key in keys:
            if key.startswith(source_prefix):
                stage_state[local_prefix + key[len(source_prefix):]] = source.get(key, dtype)

    if is_first and source.has("model.embed_tokens.weight"):
        stage_state["embed_tokens.weight"] = source.get("model.embed_tokens.weight", dtype)
    if is_last:
        if source.has("model.norm.weight"):
            stage_state["norm.weight"] = source.get("model.norm.weight", dtype)
        if source.has("lm_head.weight"):
            stage_state["lm_head.weight"] = source.get("lm_head.weight", dtype)
        elif tie_word_embeddings and source.has("model.embed_tokens.weight"):
            stage_state["lm_head.weight"] = source.get("model.embed_tokens.weight", dtype)
    return stage_state


def _validate_stage_state(
    config: Any,
    state: dict[str, torch.Tensor],
    *,
    layer_start: int,
    layer_end: int,
    is_first: bool,
    is_last: bool,
    attn_implementation: str,
) -> None:
    expected = Qwen3Stage(
        config,
        layer_start,
        layer_end,
        has_embedding=is_first,
        has_lm_head=is_last,
        attn_implementation=attn_implementation,
    ).state_dict()
    missing = sorted(set(expected) - set(state))
    unexpected = sorted(set(state) - set(expected))
    shape_errors = [
        f"{key}: expected {tuple(expected[key].shape)}, got {tuple(state[key].shape)}"
        for key in sorted(set(expected).intersection(state))
        if tuple(expected[key].shape) != tuple(state[key].shape)
    ]
    if missing or unexpected or shape_errors:
        details = []
        if missing:
            details.append(f"missing={missing}")
        if unexpected:
            details.append(f"unexpected={unexpected}")
        if shape_errors:
            details.append(f"shape_errors={shape_errors}")
        raise ValueError("Qwen3 stage weight schema mismatch: " + ", ".join(details))


def import_qwen_from_hf(
    model_id: str,
    num_stages: int,
    out_dir: str | Path,
    dtype: str = "float16",
    *,
    include_tokenizer: bool = True,
    attn_implementation: str = "sdpa",
    revision: str | None = None,
) -> ModelManifest:
    """Split a Qwen3 safetensors checkpoint into MeshGPU stage artifacts."""
    transformers = _require_transformers()
    if attn_implementation not in {"eager", "sdpa", "flash_attention_2"}:
        raise ValueError(f"unsupported attention implementation: {attn_implementation!r}")
    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    if dtype not in dtype_map:
        raise ValueError(f"unsupported dtype {dtype!r}; choose one of {sorted(dtype_map)}")

    from transformers import AutoConfig, AutoTokenizer

    hf_load_kwargs = {"revision": revision} if revision is not None else {}
    hf_config = AutoConfig.from_pretrained(model_id, **hf_load_kwargs)
    if getattr(hf_config, "model_type", None) != "qwen3":
        raise ValueError(
            "Qwen3 adapter requires model_type='qwen3', got "
            f"{getattr(hf_config, 'model_type', None)!r}"
        )
    if num_stages < 1 or num_stages > int(hf_config.num_hidden_layers):
        raise ValueError(
            f"num_stages must be in [1, {hf_config.num_hidden_layers}], got {num_stages}"
        )

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    config_dict = qwen3_config_to_dict(hf_config)
    config_dict.pop("_attn_implementation", None)
    config = qwen3_config_from_dict(config_dict)
    manifest_id = uuid.uuid4().hex[:8]

    tokenizer_path: str | None = None
    if include_tokenizer:
        try:
            tokenizer = AutoTokenizer.from_pretrained(
                model_id,
                use_fast=True,
                trust_remote_code=False,
                **hf_load_kwargs,
            )
            tokenizer_path = f"tokenizer_{manifest_id}"
            _save_tokenizer_atomic(tokenizer, out / tokenizer_path)
        except Exception as exc:
            log.warning(
                "tokenizer unavailable for %r; artifact requires prompt_ids: %s",
                model_id,
                exc,
            )

    safe_root = _find_safetensor_root(model_id, revision=revision)
    if safe_root is None:
        raise RuntimeError(
            "Qwen3 sharding requires a safetensors checkpoint. "
            "Convert the source with safe_serialization=True; loading the full "
            "model into one device would defeat the fit-first guarantee."
        )
    source = _SafeTensorSource(safe_root)
    torch_dtype = dtype_map[dtype]
    ranges = split_layers(int(config.num_hidden_layers), num_stages)
    config_path = f"config_{manifest_id}.json"
    _atomic_write_text(out / config_path, json.dumps(config_dict, indent=2, sort_keys=True))

    shards: list[ShardEntry] = []
    try:
        for stage_idx, (layer_start, layer_end) in enumerate(ranges):
            is_first = stage_idx == 0
            is_last = stage_idx == num_stages - 1
            state = _stage_from_safetensors(
                source,
                layer_start,
                layer_end,
                is_first=is_first,
                is_last=is_last,
                tie_word_embeddings=bool(config.tie_word_embeddings),
                dtype=torch_dtype,
            )
            _validate_stage_state(
                config,
                state,
                layer_start=layer_start,
                layer_end=layer_end,
                is_first=is_first,
                is_last=is_last,
                attn_implementation=attn_implementation,
            )
            shard_id = f"stage_{stage_idx:02d}"
            shard_path = out / f"{shard_id}_{manifest_id}.pt"
            _atomic_torch_save(state, shard_path)
            shards.append(
                ShardEntry(
                    shard_id=shard_id,
                    path=shard_path.name,
                    byte_length=shard_path.stat().st_size,
                    sha256=_sha256_file(shard_path),
                    layer_start=layer_start,
                    layer_end=layer_end,
                    tensor_names=sorted(state),
                )
            )
    finally:
        source.close()

    extra = {
        "num_stages": num_stages,
        "framework": "transformers",
        "transformers_version": getattr(transformers, "__version__", "unknown"),
        "config_class": "Qwen3Config",
        "attn_implementation": attn_implementation,
        "layer_types": list(getattr(config, "layer_types", [])),
        "rope_scaling": getattr(config, "rope_scaling", None),
        "attention_bias": bool(getattr(config, "attention_bias", False)),
        "source_revision": revision or "unspecified",
    }
    meta = ManifestMeta(
        model_family="qwen3",
        model_id=model_id,
        adapter="qwen3_hf_v1",
        num_layers=int(config.num_hidden_layers),
        hidden_size=int(config.hidden_size),
        num_attention_heads=int(config.num_attention_heads),
        num_kv_heads=int(config.num_key_value_heads),
        head_dim=int(config.head_dim),
        vocab_size=int(config.vocab_size),
        max_position_embeddings=int(config.max_position_embeddings),
        compute_dtype=dtype,
        weight_format="pytorch",
        tied_embeddings=bool(config.tie_word_embeddings),
        extra=extra,
    )
    manifest = ModelManifest(
        manifest_id=manifest_id,
        meta=meta,
        shards=shards,
        tokenizer_path=tokenizer_path,
        config_path=config_path,
        config_hash=ModelManifest.compute_config_hash(config_dict),
    )
    manifest.save(out / "manifest.json")
    return manifest


def load_qwen_config(
    manifest_or_dir: ModelManifest | str | Path,
    *,
    artifact_root: str | Path | None = None,
) -> Any:
    """Load the exact Qwen3Config stored beside an artifact."""
    if isinstance(manifest_or_dir, ModelManifest):
        manifest = manifest_or_dir
        root = Path(artifact_root) if artifact_root is not None else Path(".")
    else:
        root = Path(manifest_or_dir)
        manifest = ModelManifest.load(root / "manifest.json")
    if manifest.meta.model_family != "qwen3" or manifest.meta.adapter != "qwen3_hf_v1":
        raise ValueError("manifest is not a qwen3_hf_v1 artifact")
    config_path = _resolve_artifact_path(root, manifest.config_path or "config.json")
    if not config_path.exists():
        raise FileNotFoundError(f"Qwen3 config not found: {config_path}")
    values = json.loads(config_path.read_text())
    if not isinstance(values, dict):
        raise ValueError("Qwen3 config file must contain an object")
    actual_hash = ModelManifest.compute_config_hash(values)
    if manifest.config_hash and actual_hash != manifest.config_hash:
        raise ValueError(
            f"Qwen3 config hash mismatch: expected {manifest.config_hash}, got {actual_hash}"
        )
    config = qwen3_config_from_dict(values)
    validate_qwen_manifest_config(manifest, config)
    return config


def validate_qwen_manifest_config(manifest: ModelManifest, config: Any) -> None:
    meta = manifest.meta
    expected = {
        "num_layers": int(config.num_hidden_layers),
        "hidden_size": int(config.hidden_size),
        "num_attention_heads": int(config.num_attention_heads),
        "num_kv_heads": int(config.num_key_value_heads),
        "head_dim": int(config.head_dim),
        "vocab_size": int(config.vocab_size),
        "max_position_embeddings": int(config.max_position_embeddings),
    }
    mismatches = [
        f"{name}: manifest={getattr(meta, name)!r}, config={value!r}"
        for name, value in expected.items()
        if getattr(meta, name) != value
    ]
    if meta.tied_embeddings != bool(config.tie_word_embeddings):
        mismatches.append("tied_embeddings does not match Qwen3Config")
    if mismatches:
        raise ValueError("manifest/config mismatch: " + "; ".join(mismatches))


def validate_manifest_layout(manifest: ModelManifest) -> list[ShardEntry]:
    ordered = sorted(manifest.shards, key=lambda shard: shard.layer_start)
    expected = 0
    for shard in ordered:
        if shard.layer_start != expected:
            raise ValueError(
                f"manifest shard {shard.shard_id} starts at {shard.layer_start}; "
                f"expected {expected}"
            )
        if shard.layer_end <= shard.layer_start:
            raise ValueError(f"manifest shard {shard.shard_id} has an empty range")
        expected = shard.layer_end
    if expected != manifest.meta.num_layers:
        raise ValueError(
            f"manifest covers [0, {expected}) but config has {manifest.meta.num_layers} layers"
        )
    return ordered


def build_qwen_pipeline_from_manifest(
    manifest_or_dir: ModelManifest | str | Path,
    *,
    artifact_root: str | Path | None = None,
    devices: list[torch.device] | None = None,
    job_id: str = "local",
    transport: str = "cpu",
    activation_checkpointing: bool = False,
    layer_ranges: Sequence[tuple[int, int]] | None = None,
) -> list[Any]:
    if isinstance(manifest_or_dir, ModelManifest):
        manifest = manifest_or_dir
        root = Path(artifact_root) if artifact_root is not None else Path(".")
    else:
        root = Path(manifest_or_dir)
        manifest = ModelManifest.load(root / "manifest.json")
    ordered = validate_manifest_layout(manifest)
    config = load_qwen_config(manifest, artifact_root=root)
    ranges = (
        _validate_requested_ranges(layer_ranges, int(config.num_hidden_layers))
        if layer_ranges is not None
        else [(shard.layer_start, shard.layer_end) for shard in ordered]
    )
    if devices is None:
        devices = [torch.device("cpu")] * len(ranges)
    if len(devices) != len(ranges):
        raise ValueError(f"need {len(ranges)} devices, got {len(devices)}")
    if layer_ranges is not None:
        return [
            _build_qwen_stage_for_range(
                manifest,
                config,
                ordered,
                stage_id,
                layer_range,
                is_last=stage_id == len(ranges) - 1,
                device=devices[stage_id],
                job_id=job_id,
                artifact_root=root,
                transport=transport,
                activation_checkpointing=activation_checkpointing,
            )
            for stage_id, layer_range in enumerate(ranges)
        ]
    return [
        build_qwen_stage_from_manifest(
            manifest,
            index,
            device=devices[index],
            job_id=job_id,
            artifact_root=root,
            validated_config=config,
            ordered_shards=ordered,
            transport=transport,
            activation_checkpointing=activation_checkpointing,
        )
        for index in range(len(ordered))
    ]


def _build_qwen_stage_for_range(
    manifest: ModelManifest,
    config: Any,
    ordered_shards: list[ShardEntry],
    stage_id: int,
    layer_range: tuple[int, int],
    *,
    is_last: bool,
    device: torch.device,
    job_id: str,
    artifact_root: Path,
    transport: str,
    activation_checkpointing: bool,
) -> Any:
    """Build an official Qwen stage from a planner-selected layer range."""
    from meshgpu.backends.portable.stage_worker import StageContext, StageWorker

    layer_start, layer_end = layer_range
    is_first = stage_id == 0
    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    try:
        dtype = dtype_map[manifest.meta.compute_dtype]
    except KeyError as exc:
        raise ValueError(
            f"unsupported artifact compute_dtype: {manifest.meta.compute_dtype!r}"
        ) from exc
    attn_implementation = manifest.meta.extra.get("attn_implementation", "sdpa")
    if not isinstance(attn_implementation, str):
        raise TypeError("manifest attn_implementation must be a string")
    stage = Qwen3Stage(
        config,
        layer_start,
        layer_end,
        has_embedding=is_first,
        has_lm_head=is_last,
        device="cpu",
        dtype=dtype,
        attn_implementation=attn_implementation,
        activation_checkpointing=activation_checkpointing,
    )
    state = _state_for_requested_range(
        manifest,
        artifact_root,
        layer_start,
        layer_end,
        is_first=is_first,
        is_last=is_last,
    )
    _validate_stage_state(
        config,
        state,
        layer_start=layer_start,
        layer_end=layer_end,
        is_first=is_first,
        is_last=is_last,
        attn_implementation=attn_implementation,
    )
    missing, unexpected = stage.load_state_dict(state, strict=True)
    if missing or unexpected:
        raise RuntimeError(
            f"Qwen3 stage {stage_id} weight mismatch — missing={missing}, "
            f"unexpected={unexpected}"
        )
    if device.type != "cpu":
        stage.to(device=device)
    context = StageContext(
        stage_id=stage_id,
        layer_start=layer_start,
        layer_end=layer_end,
        device=device,
        is_first=is_first,
        is_last=is_last,
        job_id=job_id,
        attempt_id="local",
        transport=transport,
    )
    return StageWorker(stage, context)


def build_qwen_stage_from_manifest(
    manifest_or_dir: ModelManifest | str | Path,
    stage_id: int,
    *,
    device: torch.device | None = None,
    job_id: str = "local",
    artifact_root: str | Path | None = None,
    validated_config: Any | None = None,
    ordered_shards: list[ShardEntry] | None = None,
    transport: str = "cpu",
    activation_checkpointing: bool = False,
) -> Any:
    from meshgpu.backends.portable.stage_worker import StageContext, StageWorker

    if isinstance(manifest_or_dir, ModelManifest):
        manifest = manifest_or_dir
        root = Path(artifact_root) if artifact_root is not None else Path(".")
    else:
        root = Path(manifest_or_dir)
        manifest = ModelManifest.load(root / "manifest.json")
    ordered = ordered_shards or validate_manifest_layout(manifest)
    if stage_id < 0 or stage_id >= len(ordered):
        raise IndexError(f"stage_id {stage_id} out of range [0, {len(ordered)})")
    config = validated_config or load_qwen_config(manifest, artifact_root=root)
    device = torch.device("cpu") if device is None else torch.device(device)
    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    try:
        dtype = dtype_map[manifest.meta.compute_dtype]
    except KeyError as exc:
        raise ValueError(
            f"unsupported artifact compute_dtype: {manifest.meta.compute_dtype!r}"
        ) from exc

    shard = ordered[stage_id]
    extra = manifest.meta.extra
    attn_implementation = str(extra.get("attn_implementation", "sdpa"))
    stage = Qwen3Stage(
        config,
        shard.layer_start,
        shard.layer_end,
        has_embedding=stage_id == 0,
        has_lm_head=stage_id == len(ordered) - 1,
        device="cpu",
        dtype=dtype,
        attn_implementation=attn_implementation,
        activation_checkpointing=activation_checkpointing,
    )
    shard_file = _resolve_artifact_path(root, shard.path)
    if not shard_file.exists():
        raise FileNotFoundError(f"shard not found: {shard_file}")
    if shard_file.stat().st_size != shard.byte_length:
        raise ValueError(f"shard {shard.shard_id} size mismatch")
    actual_sha = _sha256_file(shard_file)
    if actual_sha != shard.sha256:
        raise ValueError(
            f"shard {shard.shard_id} hash mismatch: expected {shard.sha256}, got {actual_sha}"
        )
    state = torch.load(shard_file, map_location="cpu", weights_only=True)
    missing, unexpected = stage.load_state_dict(state, strict=True)
    if missing or unexpected:
        raise RuntimeError(
            f"Qwen3 stage {stage_id} weight mismatch — missing={missing}, unexpected={unexpected}"
        )
    if device.type != "cpu":
        stage.to(device=device)
    context = StageContext(
        stage_id=stage_id,
        layer_start=shard.layer_start,
        layer_end=shard.layer_end,
        device=device,
        is_first=stage_id == 0,
        is_last=stage_id == len(ordered) - 1,
        job_id=job_id,
        attempt_id="local",
        transport=transport,
    )
    return StageWorker(stage, context)
