"""
Artifact store — download, cache and verify model shards.
MVP uses a local filesystem store; interface allows swapping to S3-compatible.
"""
from __future__ import annotations

import hashlib
import logging
import os
import shutil
import uuid
from pathlib import Path

from meshgpu.artifacts.manifest import ModelManifest, ShardEntry

log = logging.getLogger(__name__)

_CHUNK_SIZE = 8 * 1024 * 1024  # 8 MiB read/copy chunks


class ArtifactStore:
    def __init__(self, root: str | Path) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    def manifest_path(self, manifest_id: str) -> Path:
        _validate_component(manifest_id, "manifest_id")
        return self._root / manifest_id / "manifest.json"

    def shard_path(self, manifest_id: str, shard_id: str) -> Path:
        _validate_component(manifest_id, "manifest_id")
        _validate_component(shard_id, "shard_id")
        return self._root / manifest_id / "shards" / shard_id

    def has_shard(self, manifest_id: str, shard_id: str) -> bool:
        return self.shard_path(manifest_id, shard_id).exists()

    def load_manifest(self, manifest_id: str) -> ModelManifest:
        p = self.manifest_path(manifest_id)
        if not p.exists():
            raise FileNotFoundError(f"manifest {manifest_id!r} not found in store")
        return ModelManifest.load(p)

    def save_manifest(self, manifest: ModelManifest) -> None:
        p = self.manifest_path(manifest.manifest_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        manifest.save(p)
        log.info("saved manifest %s", manifest.manifest_id)

    def ingest_shard(
        self,
        manifest_id: str,
        shard: ShardEntry,
        source_path: str | Path,
    ) -> None:
        """Copy shard from source_path into the store, verifying sha256."""
        dest = self.shard_path(manifest_id, shard.shard_id)
        dest.parent.mkdir(parents=True, exist_ok=True)
        src = Path(source_path)
        if not src.exists():
            raise FileNotFoundError(f"source shard not found: {src}")

        sha = _sha256_file(src)
        if sha != shard.sha256:
            raise ValueError(
                f"shard {shard.shard_id}: sha256 mismatch "
                f"(expected {shard.sha256}, got {sha})"
            )
        if src.stat().st_size != shard.byte_length:
            raise ValueError(
                f"shard {shard.shard_id}: size mismatch "
                f"(expected {shard.byte_length}, got {src.stat().st_size})"
            )
        # Copy beside the final path and publish with rename.  A process or
        # machine crash during copy must never make a partially-written shard
        # look like a usable artifact to a later worker.
        temporary = dest.with_name(f".{dest.name}.{uuid.uuid4().hex}.tmp")
        try:
            shutil.copy2(src, temporary)
            copied_size = temporary.stat().st_size
            copied_sha = _sha256_file(temporary)
            if copied_size != shard.byte_length:
                raise ValueError(
                    f"shard {shard.shard_id}: copied size mismatch "
                    f"(expected {shard.byte_length}, got {copied_size})"
                )
            if copied_sha != shard.sha256:
                raise ValueError(
                    f"shard {shard.shard_id}: copied sha256 mismatch "
                    f"(expected {shard.sha256}, got {copied_sha})"
                )
            with temporary.open("rb") as copied:
                os.fsync(copied.fileno())
            os.replace(temporary, dest)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        log.info("ingested shard %s/%s", manifest_id, shard.shard_id)

    def verify_shard(self, manifest_id: str, shard: ShardEntry) -> bool:
        """Return True iff shard is present and hash matches."""
        p = self.shard_path(manifest_id, shard.shard_id)
        if not p.exists():
            return False
        if p.stat().st_size != shard.byte_length:
            return False
        return _sha256_file(p) == shard.sha256

    def verify_manifest(self, manifest_id: str) -> list[str]:
        """Return list of missing/corrupt shard IDs."""
        manifest = self.load_manifest(manifest_id)
        bad = []
        for shard in manifest.shards:
            if not self.verify_shard(manifest_id, shard):
                bad.append(shard.shard_id)
        return bad

    def open_shard(self, manifest_id: str, shard_id: str):
        """Return an open binary file handle for reading."""
        p = self.shard_path(manifest_id, shard_id)
        if not p.exists():
            raise FileNotFoundError(f"shard {manifest_id}/{shard_id} not in store")
        return p.open("rb")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(_CHUNK_SIZE):
            h.update(chunk)
    return h.hexdigest()


def _validate_component(value: str, name: str) -> None:
    """Reject path-like IDs before they are joined to the store root."""
    candidate = Path(value)
    if (
        not value
        or value in {".", ".."}
        or candidate.is_absolute()
        or candidate.name != value
    ):
        raise ValueError(f"{name} must be a single relative path component")
