"""Model manifest — immutable descriptor of a sharded model artifact."""
from __future__ import annotations

import hashlib
import json
import os
import uuid
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class ShardEntry(BaseModel):
    shard_id: str          # e.g. "layer_00_15"
    path: str              # relative to artifact root
    byte_length: int
    sha256: str
    layer_start: int       # inclusive
    layer_end: int         # exclusive
    tensor_names: list[str]

    @field_validator("path")
    @classmethod
    def relative_path_only(cls, value: str) -> str:
        path = Path(value)
        if not value or path == Path(".") or path.is_absolute() or ".." in path.parts:
            raise ValueError("shard path must be relative and contained in the artifact")
        return value

    @field_validator("shard_id")
    @classmethod
    def non_empty_shard_id(cls, value: str) -> str:
        if not value or Path(value).name != value or value in {".", ".."}:
            raise ValueError("shard_id must be a non-empty path component")
        return value

    @field_validator("byte_length", "layer_start", "layer_end", mode="before")
    @classmethod
    def strict_integer(cls, value: int) -> int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError("shard sizes and layer bounds must be integers")
        return value

    @field_validator("byte_length")
    @classmethod
    def non_negative_size(cls, value: int) -> int:
        if value < 0:
            raise ValueError("shard byte_length must be non-negative")
        return value

    @field_validator("tensor_names")
    @classmethod
    def valid_tensor_names(cls, value: list[str]) -> list[str]:
        if not value or any(not isinstance(name, str) or not name for name in value):
            raise ValueError("shard tensor_names must contain non-empty strings")
        if len(set(value)) != len(value):
            raise ValueError("shard tensor_names must be unique")
        return value

    @model_validator(mode="after")
    def validate_layer_range(self) -> ShardEntry:
        if self.layer_start < 0:
            raise ValueError("shard layer_start must be non-negative")
        if self.layer_end <= self.layer_start:
            raise ValueError("shard layer_end must be greater than layer_start")
        if self.sha256 and (
            len(self.sha256) != 64
            or any(char not in "0123456789abcdefABCDEF" for char in self.sha256)
        ):
            raise ValueError("shard sha256 must be a 64-character hexadecimal digest")
        return self


class ManifestMeta(BaseModel):
    model_family: str      # e.g. "llama_dense"
    model_id: str          # unique revision ID (hash of config + weights)
    adapter: str           # e.g. "llama_dense_v1"
    num_layers: int
    hidden_size: int
    num_attention_heads: int
    num_kv_heads: int
    head_dim: int
    vocab_size: int
    max_position_embeddings: int
    compute_dtype: str     # "float16", "bfloat16", "float32"
    weight_format: str     # "safetensors"
    tied_embeddings: bool = False
    extra: dict[str, Any] = Field(default_factory=dict)

    @field_validator("model_family", "model_id", "adapter")
    @classmethod
    def non_empty_identity(cls, value: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise ValueError("manifest model identity fields must be non-empty strings")
        return value

    @field_validator(
        "num_layers",
        "hidden_size",
        "num_attention_heads",
        "num_kv_heads",
        "head_dim",
        "vocab_size",
        "max_position_embeddings",
        mode="before",
    )
    @classmethod
    def strict_positive_integer(cls, value: int) -> int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError("manifest dimensions must be integers")
        if value < 1:
            raise ValueError("manifest dimensions must be positive")
        return value

    @field_validator("compute_dtype")
    @classmethod
    def supported_compute_dtype(cls, value: str) -> str:
        if value not in {"float16", "bfloat16", "float32"}:
            raise ValueError(f"unsupported manifest compute_dtype: {value!r}")
        return value

    @field_validator("weight_format")
    @classmethod
    def supported_weight_format(cls, value: str) -> str:
        if value not in {"safetensors", "pytorch", "pt"}:
            raise ValueError(f"unsupported manifest weight_format: {value!r}")
        return value

    @model_validator(mode="after")
    def validate_attention_shape(self) -> ManifestMeta:
        if self.num_attention_heads % self.num_kv_heads != 0:
            raise ValueError(
                "manifest num_attention_heads must be divisible by num_kv_heads"
            )
        if self.num_kv_heads > self.num_attention_heads:
            raise ValueError("manifest num_kv_heads must not exceed attention heads")
        if self.head_dim % 2:
            raise ValueError("manifest head_dim must be even for rotary embeddings")
        return self


class ModelManifest(BaseModel):
    schema_version: int = 1
    manifest_id: str
    meta: ManifestMeta
    shards: list[ShardEntry]
    tokenizer_path: str | None = None
    config_path: str | None = None
    config_hash: str = ""

    @field_validator("schema_version", mode="before")
    @classmethod
    def valid_schema_version(cls, value: int) -> int:
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError("schema_version must be a positive integer")
        return value

    @field_validator("manifest_id")
    @classmethod
    def valid_manifest_id(cls, value: str) -> str:
        if (
            not isinstance(value, str)
            or not value
            or value in {".", ".."}
            or Path(value).name != value
            or Path(value).is_absolute()
        ):
            raise ValueError("manifest_id must be a single relative path component")
        return value

    @field_validator("config_hash")
    @classmethod
    def valid_config_hash(cls, value: str) -> str:
        if value and (
            len(value) % 2
            or any(char not in "0123456789abcdefABCDEF" for char in value)
        ):
            raise ValueError("config_hash must be hexadecimal")
        return value

    @field_validator("shards")
    @classmethod
    def shards_non_empty(cls, v: list[ShardEntry]) -> list[ShardEntry]:
        if not v:
            raise ValueError("manifest must have at least one shard")
        shard_ids = [shard.shard_id for shard in v]
        if len(set(shard_ids)) != len(shard_ids):
            raise ValueError("manifest shard IDs must be unique")
        paths = [shard.path for shard in v]
        if len(set(paths)) != len(paths):
            raise ValueError("manifest shard paths must be unique")
        return v

    @model_validator(mode="after")
    def validate_layer_coverage(self) -> ModelManifest:
        ordered = sorted(self.shards, key=lambda shard: shard.layer_start)
        expected_start = 0
        for shard in ordered:
            if shard.layer_start != expected_start:
                raise ValueError(
                    "manifest shards must cover contiguous layer ranges from zero"
                )
            expected_start = shard.layer_end
        if expected_start != self.meta.num_layers:
            raise ValueError(
                f"manifest shards cover {expected_start} layers, "
                f"expected {self.meta.num_layers}"
            )
        return self

    def shards_for_layers(self, layer_start: int, layer_end: int) -> list[ShardEntry]:
        """Return shards that overlap [layer_start, layer_end)."""
        return [
            s for s in self.shards
            if s.layer_end > layer_start and s.layer_start < layer_end
        ]

    @field_validator("tokenizer_path", "config_path")
    @classmethod
    def relative_optional_path(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value:
            raise ValueError("artifact paths must not be empty")
        path = Path(value)
        if path == Path(".") or path.is_absolute() or ".." in path.parts:
            raise ValueError("artifact paths must be relative and contained")
        return value

    def save(self, path: str | Path) -> None:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_text(self.model_dump_json(indent=2))
            with temporary.open("rb") as written:
                os.fsync(written.fileno())
            os.replace(temporary, destination)
            try:
                directory_fd = os.open(destination.parent, os.O_RDONLY)
            except OSError:
                pass
            else:
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise

    @classmethod
    def load(cls, path: str | Path) -> ModelManifest:
        return cls.model_validate_json(Path(path).read_text())

    @classmethod
    def compute_config_hash(cls, config: dict) -> str:
        blob = json.dumps(config, sort_keys=True).encode()
        return hashlib.sha256(blob).hexdigest()[:16]
