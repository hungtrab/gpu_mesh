"""
Export: training checkpoint → inference-ready artifact.

Workflow:
  1. Load all stage model_states from checkpoint.
  2. Merge LoRA adapters if present.
  3. Concatenate weight tensors by layer into safetensors shards.
  4. Write ModelManifest with sha256 per shard.
  5. Verify the exported artifact can be loaded back.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import logging
import os
import shutil
import uuid
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn

from meshgpu.artifacts.manifest import ManifestMeta, ModelManifest, ShardEntry
from meshgpu.backends.native.lora_recipe import LoRAConfig, LoRALinear, apply_lora
from meshgpu.checkpoints.coordinator import CheckpointCoordinator
from meshgpu.models.llama_dense import LlamaConfig, LlamaStage

log = logging.getLogger(__name__)


def export_checkpoint(
    coordinator: CheckpointCoordinator,
    checkpoint_id: str,
    output_dir: str | Path,
    cfg: Any,
    num_stages: int,
    *,
    merge_lora: bool = True,
    compute_dtype: str = "float16",
    model_id: str | None = None,
    tokenizer_source: str | Path | None = None,
    lora_config: LoRAConfig | None = None,
    attn_implementation: str | None = None,
) -> ModelManifest:
    """
    Export a training checkpoint to an inference-ready artifact.

    The model adapter is selected from ``cfg``.  Keeping this dispatch at the
    artifact boundary is important: the training driver does not need to
    know whether a stage contains the handwritten Llama adapter or official
    Hugging Face Qwen3 blocks.  Each adapter reconstructs only its own stage,
    loads the checkpoint shard strictly, and writes a manifest that its
    inference loader can validate.
    """
    if _is_qwen_config(cfg):
        return _export_qwen_checkpoint(
            coordinator,
            checkpoint_id,
            output_dir,
            cfg,
            num_stages,
            merge_lora=merge_lora,
            compute_dtype=compute_dtype,
            model_id=model_id,
            tokenizer_source=tokenizer_source,
            lora_config=lora_config,
            attn_implementation=attn_implementation,
        )
    if not isinstance(cfg, LlamaConfig):
        raise TypeError(
            "unsupported export config; expected LlamaConfig or Qwen3Config, "
            f"got {type(cfg).__name__}"
        )
    return _export_llama_checkpoint(
        coordinator,
        checkpoint_id,
        output_dir,
        cfg,
        num_stages,
        merge_lora=merge_lora,
        compute_dtype=compute_dtype,
        model_id=model_id,
        tokenizer_source=tokenizer_source,
        lora_config=lora_config,
    )


def _export_llama_checkpoint(
    coordinator: CheckpointCoordinator,
    checkpoint_id: str,
    output_dir: str | Path,
    cfg: LlamaConfig,
    num_stages: int,
    *,
    merge_lora: bool,
    compute_dtype: str,
    model_id: str | None,
    tokenizer_source: str | Path | None,
    lora_config: LoRAConfig | None,
) -> ModelManifest:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    shards_dir = output_dir / "shards"
    shards_dir.mkdir(exist_ok=True)

    source_model_id = model_id or f"export_{checkpoint_id[:8]}"
    # ``manifest_id`` is also validated as a single relative path component;
    # Hugging Face IDs commonly contain a slash (``org/model``), so they must
    # never be used as the artifact identifier directly.
    manifest_id = _new_export_manifest_id(checkpoint_id)
    dtype_map = {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }
    if compute_dtype not in dtype_map:
        raise ValueError(f"unsupported compute_dtype: {compute_dtype!r}")
    dtype = dtype_map[compute_dtype]

    if num_stages < 1 or num_stages > cfg.num_hidden_layers:
        raise ValueError(
            f"num_stages must be in [1, {cfg.num_hidden_layers}], got {num_stages}"
        )

    shard_entries: list[ShardEntry] = []
    artifact_revision = uuid.uuid4().hex[:8]

    # Reconstruct each stage model and save its state dict
    layer_cursor = 0
    n = cfg.num_hidden_layers
    base, rem = divmod(n, num_stages)

    for i in range(num_stages):
        is_first = i == 0
        is_last = i == num_stages - 1
        n_l = base + (1 if i < rem else 0)
        ls, le = layer_cursor, layer_cursor + n_l
        layer_cursor = le

        stage = LlamaStage(
            cfg, ls, le,
            has_embedding=is_first,
            has_lm_head=is_last,
        )
        payload = coordinator.load_stage(checkpoint_id, stage=i)
        model_state = payload["model"]
        has_lora = any("lora_A" in key or "lora_B" in key for key in model_state)
        if has_lora:
            if not merge_lora:
                raise ValueError(
                    "adapter-only export is not supported by the LlamaStage inference loader; "
                    "set merge_lora=True"
                )
            if lora_config is None:
                raise ValueError(
                    "checkpoint contains LoRA weights; provide the original lora_config "
                    "so alpha/rank are preserved during merge"
                )
            apply_lora(stage, lora_config)
            stage.load_state_dict(model_state, strict=True)
        else:
            missing, unexpected = stage.load_state_dict(model_state, strict=True)
            if missing or unexpected:
                raise RuntimeError(
                    f"stage {i} checkpoint state mismatch: "
                    f"missing={missing}, unexpected={unexpected}"
                )

        if merge_lora:
            _merge_lora_inplace(stage)

        # Cast to export dtype
        stage = stage.to(dtype)

        # Save as .pt (safetensors would be preferred; use .pt for MVP)
        shard_filename = (
            f"stage_{i:02d}_layers_{ls:04d}_{le:04d}_{artifact_revision}.pt"
        )
        shard_path = shards_dir / shard_filename
        _atomic_torch_save(stage.state_dict(), shard_path)

        sha = _sha256(shard_path)
        tensor_names = list(stage.state_dict().keys())

        shard_entries.append(ShardEntry(
            shard_id=f"stage_{i:02d}",
            path=str(shard_path.relative_to(output_dir)),
            byte_length=shard_path.stat().st_size,
            sha256=sha,
            layer_start=ls,
            layer_end=le,
            tensor_names=tensor_names,
        ))
        log.info("exported stage %d → %s (%.1f MiB)", i, shard_filename,
                 shard_path.stat().st_size / (1024 ** 2))

    meta = ManifestMeta(
        model_family="llama_dense",
        model_id=source_model_id,
        adapter="llama_dense_v1",
        num_layers=cfg.num_hidden_layers,
        hidden_size=cfg.hidden_size,
        num_attention_heads=cfg.num_attention_heads,
        num_kv_heads=cfg.num_key_value_heads,
        head_dim=cfg.head_dim,
        vocab_size=cfg.vocab_size,
        max_position_embeddings=cfg.max_position_embeddings,
        compute_dtype=compute_dtype,
        weight_format="pt",
        tied_embeddings=cfg.tie_word_embeddings,
        extra={
            "intermediate_size": cfg.intermediate_size,
            "rms_norm_eps": cfg.rms_norm_eps,
            "rope_theta": cfg.rope_theta,
            "attn_implementation": cfg.attention_implementation,
        },
    )

    # Keep the exact adapter config next to the manifest.  Falling back to a
    # hidden_size*4 MLP is not safe for real Llama-family variants.
    config_json = json.dumps({
            "vocab_size": cfg.vocab_size,
            "hidden_size": cfg.hidden_size,
            "intermediate_size": cfg.intermediate_size,
            "num_hidden_layers": cfg.num_hidden_layers,
            "num_attention_heads": cfg.num_attention_heads,
            "num_key_value_heads": cfg.num_key_value_heads,
            "head_dim": cfg.head_dim,
            "max_position_embeddings": cfg.max_position_embeddings,
            "rms_norm_eps": cfg.rms_norm_eps,
            "rope_theta": cfg.rope_theta,
            "tie_word_embeddings": cfg.tie_word_embeddings,
            "attention_implementation": cfg.attention_implementation,
        }, indent=2)
    config_path = f"config_{artifact_revision}.json"
    _atomic_write_text(output_dir / config_path, config_json)

    tokenizer_path: str | None = None
    if tokenizer_source is not None:
        source = Path(tokenizer_source)
        if not source.exists() or not source.is_dir():
            raise FileNotFoundError(f"tokenizer directory not found: {source}")
        tokenizer_path = f"tokenizer_{artifact_revision}"
        _copytree_atomic(source, output_dir / tokenizer_path)

    manifest = ModelManifest(
        manifest_id=manifest_id,
        meta=meta,
        shards=shard_entries,
        tokenizer_path=tokenizer_path,
        config_path=config_path,
        config_hash=ModelManifest.compute_config_hash(dataclasses.asdict(cfg)),
    )
    manifest.save(output_dir / "manifest.json")
    _verify_exported_artifact(manifest, cfg, output_dir)
    log.info("manifest written → %s", output_dir / "manifest.json")
    return manifest


def load_exported_stage(
    manifest: ModelManifest,
    stage_id: int,
    cfg: Any,
    artifact_root: str | Path,
) -> Any:
    """Load one exported stage shard back into its adapter-specific stage."""
    if manifest.meta.adapter == "qwen3_hf_v1":
        if not _is_qwen_config(cfg):
            raise TypeError("Qwen3 export must be loaded with a Qwen3Config")
        from meshgpu.artifacts.qwen_import import validate_qwen_manifest_config

        validate_qwen_manifest_config(manifest, cfg)
        from meshgpu.artifacts.qwen_import import build_qwen_stage_from_manifest

        worker = build_qwen_stage_from_manifest(
            manifest,
            stage_id,
            device=torch.device("cpu"),
            artifact_root=artifact_root,
        )
        return worker._model
    if not isinstance(cfg, LlamaConfig):
        raise TypeError("Llama export must be loaded with a LlamaConfig")
    return _load_exported_llama_stage(manifest, stage_id, cfg, artifact_root)


def _load_exported_llama_stage(
    manifest: ModelManifest,
    stage_id: int,
    cfg: LlamaConfig,
    artifact_root: str | Path,
) -> LlamaStage:
    """Load one exported Llama stage shard back for inference."""
    # Keep the loader strict about topology/configuration.  A valid hash on a
    # single shard is not enough: loading a shard under the wrong layer range
    # or model shape can produce plausible-looking but incorrect logits.
    from meshgpu.artifacts.hf_import import validate_manifest_layout

    artifact_root = Path(artifact_root)
    ordered_shards = validate_manifest_layout(manifest)
    if stage_id < 0 or stage_id >= len(ordered_shards):
        raise IndexError(f"stage_id {stage_id} out of range [0, {len(ordered_shards)})")

    _validate_manifest_config(manifest, cfg)
    shard = ordered_shards[stage_id]
    shard_path = _resolve_artifact_path(artifact_root, shard.path)
    if not shard_path.exists():
        raise FileNotFoundError(f"shard not found: {shard_path}")

    # Verify hash before loading
    sha = _sha256(shard_path)
    if sha != shard.sha256:
        raise ValueError(
            f"shard {shard.shard_id} hash mismatch: expected {shard.sha256}, got {sha}"
        )
    if shard_path.stat().st_size != shard.byte_length:
        raise ValueError(
            f"shard {shard.shard_id} size mismatch: expected {shard.byte_length}, "
            f"got {shard_path.stat().st_size}"
        )

    n_stages = len(manifest.shards)
    is_first = stage_id == 0
    is_last = stage_id == n_stages - 1

    stage = LlamaStage(
        cfg,
        shard.layer_start,
        shard.layer_end,
        has_embedding=is_first,
        has_lm_head=is_last,
    )
    dtype_map = {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }
    if manifest.meta.compute_dtype not in dtype_map:
        raise ValueError(f"unsupported compute dtype: {manifest.meta.compute_dtype!r}")
    dtype = dtype_map[manifest.meta.compute_dtype]
    state = torch.load(shard_path, weights_only=True, map_location="cpu")
    missing, unexpected = stage.load_state_dict(state, strict=True)
    if missing or unexpected:  # defensive; strict=True normally raises first
        raise RuntimeError(
            f"exported stage {stage_id} state mismatch: "
            f"missing={missing}, unexpected={unexpected}"
        )
    stage = stage.to(dtype)
    return stage


def _validate_manifest_config(manifest: ModelManifest, cfg: LlamaConfig) -> None:
    """Reject a manifest/config pair that cannot describe the same model."""
    meta = manifest.meta
    expected = {
        "num_layers": cfg.num_hidden_layers,
        "hidden_size": cfg.hidden_size,
        "num_attention_heads": cfg.num_attention_heads,
        "num_kv_heads": cfg.num_key_value_heads,
        "head_dim": cfg.head_dim,
        "vocab_size": cfg.vocab_size,
        "max_position_embeddings": cfg.max_position_embeddings,
    }
    mismatches = [
        f"{name}: manifest={getattr(meta, name)!r}, config={value!r}"
        for name, value in expected.items()
        if getattr(meta, name) != value
    ]
    if mismatches:
        raise ValueError("manifest/config mismatch: " + "; ".join(mismatches))
    if meta.tied_embeddings != cfg.tie_word_embeddings:
        raise ValueError(
            "manifest/config mismatch: "
            f"tied_embeddings: manifest={meta.tied_embeddings!r}, "
            f"config={cfg.tie_word_embeddings!r}"
        )
    if meta.model_family != "llama_dense" or meta.adapter != "llama_dense_v1":
        raise ValueError(
            "unsupported exported adapter: "
            f"family={meta.model_family!r}, adapter={meta.adapter!r}"
        )
    if meta.weight_format != "pt":
        raise ValueError(
            f"unsupported exported weight format {meta.weight_format!r}; expected 'pt'"
        )
    manifest_attention = meta.extra.get("attn_implementation")
    if (
        manifest_attention is not None
        and manifest_attention != cfg.attention_implementation
    ):
        raise ValueError(
            "manifest/config mismatch: "
            f"attn_implementation: manifest={manifest_attention!r}, "
            f"config={cfg.attention_implementation!r}"
        )
    if manifest.config_hash:
        actual = ModelManifest.compute_config_hash(dataclasses.asdict(cfg))
        if actual != manifest.config_hash:
            raise ValueError(
                "artifact config hash mismatch: "
                f"expected {manifest.config_hash}, got {actual}"
            )


def _merge_lora_inplace(stage: nn.Module) -> None:
    """Replace every LoRALinear in a stage with its merged nn.Linear."""
    if not hasattr(stage, "layers"):
        raise TypeError("LoRA merge requires a stage exposing decoder layers")
    _merge_lora_children(stage)
    log.debug(
        "LoRA merged for stage with layers [%d, %d)",
        getattr(stage, "layer_start", -1),
        getattr(stage, "layer_end", -1),
    )


def _merge_lora_children(module: nn.Module) -> None:
    for name, child in list(module.named_children()):
        if isinstance(child, LoRALinear):
            setattr(module, name, child.merge())
        else:
            _merge_lora_children(child)


def _verify_exported_artifact(
    manifest: ModelManifest,
    cfg: Any,
    artifact_root: str | Path,
) -> None:
    """Load every newly written stage through the real inference loader.

    Export is not considered successful merely because files and hashes were
    written.  This catches config, topology, dtype and state-key mismatches at
    the training-to-inference boundary while weights are still local.
    """
    for stage_id in range(len(manifest.shards)):
        load_exported_stage(manifest, stage_id, cfg, artifact_root)


def _is_qwen_config(cfg: Any) -> bool:
    return getattr(cfg, "model_type", None) == "qwen3"


def _export_qwen_checkpoint(
    coordinator: CheckpointCoordinator,
    checkpoint_id: str,
    output_dir: str | Path,
    cfg: Any,
    num_stages: int,
    *,
    merge_lora: bool,
    compute_dtype: str,
    model_id: str | None,
    tokenizer_source: str | Path | None,
    lora_config: LoRAConfig | None,
    attn_implementation: str | None,
) -> ModelManifest:
    """Export Qwen3 stage checkpoints without materializing a full model."""
    from meshgpu.models.qwen3_hf import Qwen3Stage, qwen3_config_to_dict

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    shards_dir = output_dir / "shards"
    shards_dir.mkdir(exist_ok=True)
    dtype_map = {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }
    if compute_dtype not in dtype_map:
        raise ValueError(f"unsupported compute_dtype: {compute_dtype!r}")
    n = int(cfg.num_hidden_layers)
    if num_stages < 1 or num_stages > n:
        raise ValueError(f"num_stages must be in [1, {n}], got {num_stages}")
    selected_attention = attn_implementation or str(
        getattr(cfg, "_attn_implementation", "sdpa")
    )
    if selected_attention not in {"eager", "sdpa", "flash_attention_2"}:
        raise ValueError(f"unsupported Qwen3 attention implementation: {selected_attention!r}")

    config_dict = qwen3_config_to_dict(cfg)
    config_dict.pop("_attn_implementation", None)
    config_json = json.dumps(config_dict, indent=2, sort_keys=True)
    revision = uuid.uuid4().hex[:8]
    config_path = f"config_{revision}.json"
    _atomic_write_text(output_dir / config_path, config_json)

    tokenizer_path: str | None = None
    if tokenizer_source is not None:
        source = Path(tokenizer_source)
        if not source.exists() or not source.is_dir():
            raise FileNotFoundError(f"tokenizer directory not found: {source}")
        tokenizer_path = f"tokenizer_{revision}"
        _copytree_atomic(source, output_dir / tokenizer_path)

    from meshgpu.artifacts.qwen_import import split_layers

    ranges = split_layers(n, num_stages)
    shards: list[ShardEntry] = []
    for stage_id, (layer_start, layer_end) in enumerate(ranges):
        stage = Qwen3Stage(
            cfg,
            layer_start,
            layer_end,
            has_embedding=stage_id == 0,
            has_lm_head=stage_id == num_stages - 1,
            attn_implementation=selected_attention,
        )
        payload = coordinator.load_stage(checkpoint_id, stage=stage_id)
        model_state = payload.get("model")
        if not isinstance(model_state, dict):
            raise ValueError(f"checkpoint stage {stage_id} has no model state dict")
        has_lora = any("lora_A" in key or "lora_B" in key for key in model_state)
        if has_lora:
            if not merge_lora:
                raise ValueError(
                    "adapter-only Qwen3 export is not supported by the stage loader; "
                    "set merge_lora=True"
                )
            if lora_config is None:
                raise ValueError(
                    "checkpoint contains LoRA weights; provide the original lora_config "
                    "so alpha/rank are preserved during merge"
                )
            apply_lora(stage, lora_config)
        missing, unexpected = stage.load_state_dict(model_state, strict=True)
        if missing or unexpected:
            raise RuntimeError(
                f"Qwen3 stage {stage_id} checkpoint state mismatch: "
                f"missing={missing}, unexpected={unexpected}"
            )
        if merge_lora:
            _merge_lora_inplace(stage)
        stage = stage.to(dtype_map[compute_dtype])
        filename = f"stage_{stage_id:02d}_layers_{layer_start:04d}_{layer_end:04d}_{revision}.pt"
        path = shards_dir / filename
        _atomic_torch_save(stage.state_dict(), path)
        shards.append(
            ShardEntry(
                shard_id=f"stage_{stage_id:02d}",
                path=str(path.relative_to(output_dir)),
                byte_length=path.stat().st_size,
                sha256=_sha256(path),
                layer_start=layer_start,
                layer_end=layer_end,
                tensor_names=list(stage.state_dict()),
            )
        )

    source_model_id = model_id or f"export_{checkpoint_id[:8]}"
    manifest = ModelManifest(
        manifest_id=_new_export_manifest_id(checkpoint_id),
        meta=ManifestMeta(
            model_family="qwen3",
            model_id=source_model_id,
            adapter="qwen3_hf_v1",
            num_layers=n,
            hidden_size=int(cfg.hidden_size),
            num_attention_heads=int(cfg.num_attention_heads),
            num_kv_heads=int(cfg.num_key_value_heads),
            head_dim=int(cfg.head_dim),
            vocab_size=int(cfg.vocab_size),
            max_position_embeddings=int(cfg.max_position_embeddings),
            compute_dtype=compute_dtype,
            weight_format="pytorch",
            tied_embeddings=bool(cfg.tie_word_embeddings),
            extra={
                "num_stages": num_stages,
                "framework": "transformers",
                "config_class": "Qwen3Config",
                "attn_implementation": selected_attention,
                "layer_types": list(getattr(cfg, "layer_types", [])),
            },
        ),
        shards=shards,
        tokenizer_path=tokenizer_path,
        config_path=config_path,
        config_hash=ModelManifest.compute_config_hash(config_dict),
    )
    manifest.save(output_dir / "manifest.json")
    _verify_exported_artifact(manifest, cfg, output_dir)
    return manifest


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(8 * 1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def _new_export_manifest_id(checkpoint_id: str) -> str:
    """Create a safe, collision-resistant ID for a newly exported artifact."""
    if not isinstance(checkpoint_id, str) or not checkpoint_id:
        raise ValueError("checkpoint_id must be a non-empty string")
    return f"export_{checkpoint_id[:16]}_{uuid.uuid4().hex[:12]}"


def _atomic_write_text(path: Path, contents: str) -> None:
    """Publish a small text file atomically and durably enough for local use."""
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_text(contents)
        with temporary.open("rb") as written:
            os.fsync(written.fileno())
        os.replace(temporary, path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _atomic_torch_save(state: dict, path: Path) -> None:
    """Write a shard to a temporary sibling before publishing it."""
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        torch.save(state, temporary)
        with temporary.open("rb") as written:
            os.fsync(written.fileno())
        os.replace(temporary, path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _copytree_atomic(source: Path, destination: Path) -> None:
    """Copy a tokenizer revision without mutating a previously exported one."""
    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        shutil.copytree(source, temporary)
        os.replace(temporary, destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def _resolve_artifact_path(root: Path, relative_path: str) -> Path:
    candidate = Path(relative_path)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError(f"manifest path must be relative and contained: {relative_path!r}")
    root = root.resolve()
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"manifest path escapes artifact root: {relative_path!r}") from exc
    return resolved
