"""
Import a HuggingFace Llama model and split into MeshGPU pipeline shards.

Key name mapping (HF → MeshGPU LlamaStage):
  model.embed_tokens.weight          → embed_tokens.weight        (stage 0)
  model.layers.{i}.input_layernorm.weight
    → layers.{i - layer_start}.input_layernorm.weight
  model.layers.{i}.self_attn.{q,k,v,o}_proj.weight  → layers.{local}.self_attn.*
  model.layers.{i}.mlp.{gate,up,down}_proj.weight    → layers.{local}.mlp.*
  model.layers.{i}.post_attention_layernorm.weight   → layers.{local}.post_attention_layernorm.*
  model.norm.weight                  → norm.weight                (last stage)
  lm_head.weight                     → lm_head.weight             (last stage)

Tied embeddings: if lm_head.weight absent in HF state dict, copy embed_tokens.weight.

Usage:
    from meshgpu.artifacts.hf_import import import_from_hf
    manifest = import_from_hf(
        "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
        num_stages=2,
        out_dir="./tinyllama-1b-2s",
    )

Requires: pip install transformers (only for import_from_hf; everything else is standalone).
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import logging
import os
import shutil
import uuid
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import torch

from meshgpu.artifacts.manifest import ManifestMeta, ModelManifest, ShardEntry
from meshgpu.models.llama_dense import LlamaConfig, LlamaStage

log = logging.getLogger(__name__)

_CHUNK = 8 * 1024 * 1024


class _SafeTensorSource:
    """Read individual tensors from a local HF safetensors checkpoint."""

    def __init__(self, root: Path) -> None:
        from safetensors import safe_open

        self._root = root.resolve()
        index_path = self._root / "model.safetensors.index.json"
        if index_path.exists():
            index = json.loads(index_path.read_text())
            weight_map = index.get("weight_map")
            if not isinstance(weight_map, dict) or not weight_map:
                raise ValueError(f"invalid safetensors index: {index_path}")
            self._weight_map = {str(key): str(value) for key, value in weight_map.items()}
            filenames = sorted(set(self._weight_map.values()))
        else:
            single = self._root / "model.safetensors"
            if not single.exists():
                raise FileNotFoundError("model.safetensors index/file not found")
            self._weight_map = {}
            filenames = [single.name]

        self._handles: dict[str, Any] = {}
        for filename in filenames:
            path = _resolve_model_file(self._root, filename)
            self._handles[filename] = safe_open(str(path), framework="pt", device="cpu")

        if not self._weight_map:
            handle = self._handles[filenames[0]]
            self._weight_map = {key: filenames[0] for key in handle.keys()}
        self._keys = frozenset(self._weight_map)

    def keys(self) -> frozenset[str]:
        return self._keys

    def has(self, key: str) -> bool:
        return key in self._weight_map

    def get(self, key: str, dtype: torch.dtype) -> torch.Tensor:
        filename = self._weight_map[key]
        tensor = self._handles[filename].get_tensor(key)
        return tensor.to(dtype=dtype).contiguous()

    def close(self) -> None:
        for handle in self._handles.values():
            close = getattr(handle, "__exit__", None)
            if close is not None:
                close(None, None, None)
        self._handles.clear()


def _resolve_model_file(root: Path, relative_path: str) -> Path:
    candidate = Path(relative_path)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError(f"model weight path escapes checkpoint root: {relative_path!r}")
    resolved_root = root.resolve()
    lexical_path = resolved_root / candidate
    resolved = lexical_path.resolve()
    try:
        resolved.relative_to(resolved_root)
    except ValueError as exc:
        # Hugging Face's content-addressed cache stores snapshot entries as
        # symlinks to blobs outside the snapshot directory.  Accept that
        # standard layout only when the resolved target remains inside the
        # configured HF cache; arbitrary local symlinks must still be rejected.
        if not lexical_path.is_symlink():
            raise ValueError(
                f"model weight path escapes checkpoint root: {relative_path!r}"
            ) from exc
        try:
            from huggingface_hub.constants import HF_HUB_CACHE

            cache_root = Path(HF_HUB_CACHE).expanduser().resolve()
            resolved.relative_to(cache_root)
        except (ImportError, OSError, ValueError) as cache_exc:
            raise ValueError(
                f"model weight symlink escapes trusted Hugging Face cache: "
                f"{relative_path!r}"
            ) from cache_exc
    if not resolved.exists():
        raise FileNotFoundError(f"model weight file not found: {resolved}")
    return resolved


def _find_safetensor_root(model_id: str, *, revision: str | None = None) -> Path | None:
    """Return a local checkpoint root, downloading a Hub snapshot if needed."""
    local = Path(model_id)
    if local.is_dir():
        root = local
    else:
        try:
            from huggingface_hub import snapshot_download
            download_kwargs: dict[str, Any] = {
                "allow_patterns": ["config.json", "*.safetensors", "*.json"],
            }
            if revision is not None:
                download_kwargs["revision"] = revision
            root = Path(
                snapshot_download(
                    model_id,
                    **download_kwargs,
                )
            )
        except Exception as exc:
            log.debug("could not obtain a safetensors snapshot for %r: %s", model_id, exc)
            return None
    if (root / "model.safetensors.index.json").exists() or (root / "model.safetensors").exists():
        return root
    return None


def _stage_from_safetensors(
    source: _SafeTensorSource,
    layer_start: int,
    layer_end: int,
    *,
    is_first: bool,
    is_last: bool,
    tie_word_embeddings: bool,
    dtype: torch.dtype,
) -> dict[str, torch.Tensor]:
    """Extract and locally rename one stage without materializing full state."""
    stage_sd: dict[str, torch.Tensor] = {}
    for global_i in range(layer_start, layer_end):
        hf_prefix = f"model.layers.{global_i}."
        local_prefix = f"layers.{global_i - layer_start}."
        for key in sorted(source.keys()):
            if key.startswith(hf_prefix):
                stage_sd[local_prefix + key[len(hf_prefix):]] = source.get(key, dtype)

    if is_first and source.has("model.embed_tokens.weight"):
        stage_sd["embed_tokens.weight"] = source.get("model.embed_tokens.weight", dtype)
    if is_last:
        if source.has("model.norm.weight"):
            stage_sd["norm.weight"] = source.get("model.norm.weight", dtype)
        if source.has("lm_head.weight"):
            stage_sd["lm_head.weight"] = source.get("lm_head.weight", dtype)
        elif tie_word_embeddings and source.has("model.embed_tokens.weight"):
            stage_sd["lm_head.weight"] = source.get("model.embed_tokens.weight", dtype)
    return stage_sd


# ---------------------------------------------------------------------------
# Config conversion
# ---------------------------------------------------------------------------

def hf_config_to_llama(hf_cfg: Any) -> LlamaConfig:
    """Convert a HuggingFace LlamaConfig object to MeshGPU LlamaConfig."""
    rope_scaling = getattr(hf_cfg, "rope_scaling", None)
    if rope_scaling:
        raise ValueError(
            "this adapter implements unscaled Llama RoPE only; "
            f"rope_scaling={rope_scaling!r} is not supported"
        )
    if getattr(hf_cfg, "hidden_act", "silu") != "silu":
        raise ValueError(
            "this adapter implements the SiLU SwiGLU MLP only; "
            f"hidden_act={getattr(hf_cfg, 'hidden_act', None)!r}"
        )
    if getattr(hf_cfg, "attention_bias", False) or getattr(hf_cfg, "mlp_bias", False):
        raise ValueError("this adapter supports bias-free Llama projections only")
    nhead = hf_cfg.num_attention_heads
    head_dim = getattr(hf_cfg, "head_dim", None) or (hf_cfg.hidden_size // nhead)
    return LlamaConfig(
        vocab_size=hf_cfg.vocab_size,
        hidden_size=hf_cfg.hidden_size,
        intermediate_size=hf_cfg.intermediate_size,
        num_hidden_layers=hf_cfg.num_hidden_layers,
        num_attention_heads=nhead,
        num_key_value_heads=getattr(hf_cfg, "num_key_value_heads", nhead),
        head_dim=head_dim,
        max_position_embeddings=hf_cfg.max_position_embeddings,
        rms_norm_eps=getattr(hf_cfg, "rms_norm_eps", 1e-5),
        rope_theta=getattr(hf_cfg, "rope_theta", 10000.0),
        tie_word_embeddings=getattr(hf_cfg, "tie_word_embeddings", False),
    )


# ---------------------------------------------------------------------------
# Layer partitioning
# ---------------------------------------------------------------------------

def split_layers(n_layers: int, n_stages: int) -> list[tuple[int, int]]:
    """
    Partition n_layers into n_stages contiguous [start, end) ranges.
    Remainder layers go to the first stages (keeps last stage lightest for lm_head).
    """
    if n_stages > n_layers:
        raise ValueError(f"n_stages={n_stages} > n_layers={n_layers}")
    base, rem = divmod(n_layers, n_stages)
    ranges: list[tuple[int, int]] = []
    start = 0
    for i in range(n_stages):
        end = start + base + (1 if i < rem else 0)
        ranges.append((start, end))
        start = end
    return ranges


# ---------------------------------------------------------------------------
# Weight remapping
# ---------------------------------------------------------------------------

def remap_keys(
    full_sd: dict[str, torch.Tensor],
    layer_start: int,
    layer_end: int,
    *,
    is_first: bool,
    is_last: bool,
    tie_word_embeddings: bool = False,
) -> dict[str, torch.Tensor]:
    """
    Extract weights for one pipeline stage from the full HF state dict.
    Translates global layer indices to stage-local indices.
    """
    stage_sd: dict[str, torch.Tensor] = {}

    for global_i in range(layer_start, layer_end):
        local_i = global_i - layer_start
        hf_prefix = f"model.layers.{global_i}."
        local_prefix = f"layers.{local_i}."
        for k, v in full_sd.items():
            if k.startswith(hf_prefix):
                stage_sd[local_prefix + k[len(hf_prefix):]] = v

    if is_first and "model.embed_tokens.weight" in full_sd:
        stage_sd["embed_tokens.weight"] = full_sd["model.embed_tokens.weight"]

    if is_last:
        if "model.norm.weight" in full_sd:
            stage_sd["norm.weight"] = full_sd["model.norm.weight"]
        if "lm_head.weight" in full_sd:
            stage_sd["lm_head.weight"] = full_sd["lm_head.weight"]
        elif tie_word_embeddings and "model.embed_tokens.weight" in full_sd:
            # Tied: lm_head shares embed_tokens weights
            stage_sd["lm_head.weight"] = full_sd["model.embed_tokens.weight"]

    return stage_sd


# ---------------------------------------------------------------------------
# Main importer
# ---------------------------------------------------------------------------

def import_from_hf(
    model_id: str,
    num_stages: int,
    out_dir: str | Path,
    dtype: str = "float16",
    *,
    include_tokenizer: bool = True,
    attn_implementation: str = "sdpa",
    revision: str | None = None,
) -> ModelManifest:
    """
    Load a supported HuggingFace decoder model, split it into pipeline shards,
    and write shards + manifest to out_dir.  Qwen3 is dispatched to its
    official-block adapter; Llama-family models use ``LlamaConfig``.

    Args:
        model_id: HF hub ID (for example TinyLlama/TinyLlama-1.1B-Chat-v1.0)
            or a local path. The adapter currently accepts unscaled Llama RoPE.
        num_stages: Number of pipeline stages.
        out_dir: Output directory (created if absent).
        dtype: Weight dtype — "float16", "bfloat16", or "float32".
        attn_implementation: Attention backend requested by the stage adapter.
        revision: Optional immutable Hugging Face branch, tag, or commit.

    Returns:
        ModelManifest describing the split model.

    Requires:
        pip install transformers
    """
    try:
        from transformers import AutoConfig, AutoModelForCausalLM
    except ImportError:
        raise RuntimeError(
            "HuggingFace import requires the optional dependency; "
            "install with `pip install 'meshgpu[hf]'`"
        )

    if num_stages < 1:
        raise ValueError("num_stages must be positive")
    if attn_implementation not in {"eager", "sdpa", "flash_attention_2"}:
        raise ValueError(
            f"unsupported attention implementation: {attn_implementation!r}"
        )
    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    if dtype not in dtype_map:
        raise ValueError(f"unsupported dtype {dtype!r}; choose one of {sorted(dtype_map)}")

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    torch_dtype = dtype_map[dtype]

    log.info("Loading HF config: %s", model_id)
    hf_load_kwargs = {"revision": revision} if revision is not None else {}
    hf_cfg = AutoConfig.from_pretrained(model_id, **hf_load_kwargs)
    model_type = getattr(hf_cfg, "model_type", "llama")
    if model_type == "qwen3":
        # Keep the Qwen implementation in its own adapter.  In particular,
        # never pass Qwen weights through hf_config_to_llama: q_norm/k_norm,
        # cache metadata and attention semantics would be lost.
        from meshgpu.artifacts.qwen_import import import_qwen_from_hf

        return import_qwen_from_hf(
            model_id,
            num_stages,
            out_dir,
            dtype,
            include_tokenizer=include_tokenizer,
            attn_implementation=attn_implementation,
            revision=revision,
        )
    if model_type != "llama":
        raise ValueError(
            f"model type {model_type!r} is not supported by the llama_dense adapter"
        )
    if attn_implementation == "flash_attention_2":
        raise ValueError(
            "flash_attention_2 is supported only by the Qwen3 HF adapter; "
            "use --attn-implementation sdpa for Llama"
        )
    cfg = hf_config_to_llama(hf_cfg)
    cfg.attention_implementation = attn_implementation
    tie = getattr(hf_cfg, "tie_word_embeddings", False)
    if num_stages > cfg.num_hidden_layers:
        raise ValueError(
            f"num_stages={num_stages} exceeds num_hidden_layers={cfg.num_hidden_layers}"
        )

    manifest_id = uuid.uuid4().hex[:8]
    tokenizer_path: str | None = None
    if include_tokenizer:
        try:
            from transformers import AutoTokenizer
            tokenizer = AutoTokenizer.from_pretrained(
                model_id,
                use_fast=True,
                trust_remote_code=False,
                **hf_load_kwargs,
            )
            tokenizer_path = f"tokenizer_{manifest_id}"
            _save_tokenizer_atomic(tokenizer, out / tokenizer_path)
        except Exception as exc:
            # Some local model-only checkpoints intentionally contain no
            # tokenizer files (common in unit tests and weight-only exports).
            # Keep the weight artifact usable with prompt_ids while making the
            # missing text path explicit to callers.
            log.warning(
                "tokenizer unavailable for %r; artifact will require prompt_ids: %s",
                model_id,
                exc,
            )

    log.info("Loading weights (dtype=%s) …", dtype)
    safe_root = _find_safetensor_root(model_id, revision=revision)
    safe_source: _SafeTensorSource | None = None
    full_sd: dict[str, torch.Tensor] | None = None
    if safe_root is not None:
        try:
            safe_source = _SafeTensorSource(safe_root)
            log.info("Using indexed safetensors reader at %s", safe_root)
        except Exception as exc:
            log.warning("could not open safetensors checkpoint; falling back to HF loader: %s", exc)
            safe_source = None

    if safe_source is None:
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=torch_dtype,
            low_cpu_mem_usage=True,
            **hf_load_kwargs,
        )
        full_sd = {key: value.contiguous() for key, value in model.state_dict().items()}
        del model

    # Save LlamaConfig so build_pipeline_from_manifest can reconstruct it
    config_path = f"config_{manifest_id}.json"
    _atomic_write_text(out / config_path, json.dumps(dataclasses.asdict(cfg), indent=2))

    n = cfg.num_hidden_layers
    ranges = split_layers(n, num_stages)
    shards: list[ShardEntry] = []

    try:
        for stage_idx, (ls, le) in enumerate(ranges):
            is_first = stage_idx == 0
            is_last = stage_idx == num_stages - 1
            if safe_source is not None:
                stage_sd = _stage_from_safetensors(
                    safe_source,
                    ls,
                    le,
                    is_first=is_first,
                    is_last=is_last,
                    tie_word_embeddings=tie,
                    dtype=torch_dtype,
                )
            else:
                assert full_sd is not None
                stage_sd = remap_keys(
                    full_sd,
                    ls,
                    le,
                    is_first=is_first,
                    is_last=is_last,
                    tie_word_embeddings=tie,
                )

            _validate_stage_state(
                cfg,
                stage_sd,
                layer_start=ls,
                layer_end=le,
                is_first=is_first,
                is_last=is_last,
                stage_idx=stage_idx,
            )

            shard_id = f"stage_{stage_idx:02d}"
            # Keep shard names revision-specific.  If conversion is rerun in
            # an existing directory, an old committed manifest still points
            # at its immutable files while the new revision is being built.
            shard_file = out / f"{shard_id}_{manifest_id}.pt"
            _atomic_torch_save(stage_sd, shard_file)

            sha = _sha256_file(shard_file)
            size = shard_file.stat().st_size
            shards.append(ShardEntry(
                shard_id=shard_id,
                path=shard_file.name,
                byte_length=size,
                sha256=sha,
                layer_start=ls,
                layer_end=le,
                tensor_names=sorted(stage_sd.keys()),
            ))
            log.info("Stage %d  layers [%d, %d)  %s  %.1f MB",
                     stage_idx, ls, le, shard_id, size / 1e6)
    finally:
        if safe_source is not None:
            safe_source.close()
        del full_sd

    meta = ManifestMeta(
        model_family="llama_dense",
        model_id=model_id,
        adapter="llama_dense_v1",
        num_layers=n,
        hidden_size=cfg.hidden_size,
        num_attention_heads=cfg.num_attention_heads,
        num_kv_heads=cfg.num_key_value_heads,
        head_dim=cfg.head_dim,
        vocab_size=cfg.vocab_size,
        max_position_embeddings=cfg.max_position_embeddings,
        compute_dtype=dtype,
        weight_format="pytorch",
        tied_embeddings=tie,
        extra={
            "num_stages": num_stages,
            "intermediate_size": cfg.intermediate_size,
            "rms_norm_eps": cfg.rms_norm_eps,
            "rope_theta": cfg.rope_theta,
            "attn_implementation": cfg.attention_implementation,
            "source_revision": revision or "unspecified",
        },
    )
    manifest = ModelManifest(
        manifest_id=manifest_id,
        meta=meta,
        shards=shards,
        tokenizer_path=tokenizer_path,
        config_path=config_path,
        config_hash=ModelManifest.compute_config_hash(dataclasses.asdict(cfg)),
    )
    manifest.save(out / "manifest.json")
    log.info("Manifest saved → %s", out / "manifest.json")
    return manifest


def load_llama_config(
    manifest_or_dir: ModelManifest | str | Path,
    *,
    artifact_root: str | Path | None = None,
) -> LlamaConfig:
    """Load the execution config associated with a MeshGPU artifact."""
    if isinstance(manifest_or_dir, ModelManifest):
        manifest = manifest_or_dir
        root = Path(artifact_root) if artifact_root is not None else Path(".")
    else:
        root = Path(manifest_or_dir)
        manifest = ModelManifest.load(root / "manifest.json")

    config_path = _resolve_artifact_path(root, manifest.config_path or "config.json")
    if config_path.exists():
        return LlamaConfig(**json.loads(config_path.read_text()))

    extra = manifest.meta.extra
    return LlamaConfig(
        vocab_size=manifest.meta.vocab_size,
        hidden_size=manifest.meta.hidden_size,
        intermediate_size=extra.get("intermediate_size", manifest.meta.hidden_size * 4),
        num_hidden_layers=manifest.meta.num_layers,
        num_attention_heads=manifest.meta.num_attention_heads,
        num_key_value_heads=manifest.meta.num_kv_heads,
        head_dim=manifest.meta.head_dim,
        max_position_embeddings=manifest.meta.max_position_embeddings,
        rms_norm_eps=extra.get("rms_norm_eps", 1e-5),
        rope_theta=extra.get("rope_theta", 10000.0),
        tie_word_embeddings=manifest.meta.tied_embeddings,
        attention_implementation=extra.get("attn_implementation", "sdpa"),
    )


def validate_manifest_layout(manifest: ModelManifest) -> list[ShardEntry]:
    """Validate ordered, contiguous stage ranges and return them sorted."""
    ordered = sorted(manifest.shards, key=lambda shard: shard.layer_start)
    expected_start = 0
    for index, shard in enumerate(ordered):
        if shard.layer_start != expected_start:
            raise ValueError(
                f"manifest stage {index} starts at layer {shard.layer_start}; "
                f"expected {expected_start}"
            )
        if shard.layer_end <= shard.layer_start:
            raise ValueError(f"manifest shard {shard.shard_id} has an empty layer range")
        expected_start = shard.layer_end
    if expected_start != manifest.meta.num_layers:
        raise ValueError(
            f"manifest covers layers [0, {expected_start}), "
            f"but config declares {manifest.meta.num_layers} layers"
        )
    return ordered


def validate_manifest_config(manifest: ModelManifest, cfg: LlamaConfig) -> None:
    """Ensure manifest metadata and execution config describe one model."""
    meta = manifest.meta
    expected = {
        "num_layers": cfg.num_hidden_layers,
        "hidden_size": cfg.hidden_size,
        "num_attention_heads": cfg.num_attention_heads,
        "num_kv_heads": cfg.num_key_value_heads,
        "head_dim": cfg.head_dim,
        "vocab_size": cfg.vocab_size,
        "max_position_embeddings": cfg.max_position_embeddings,
    }
    mismatches = [
        f"{name}: manifest={getattr(meta, name)!r}, config={value!r}"
        for name, value in expected.items()
        if getattr(meta, name) != value
    ]
    if meta.tied_embeddings != cfg.tie_word_embeddings:
        mismatches.append(
            "tied_embeddings: "
            f"manifest={meta.tied_embeddings!r}, config={cfg.tie_word_embeddings!r}"
        )
    if mismatches:
        raise ValueError("manifest/config mismatch: " + "; ".join(mismatches))
    if meta.model_family != "llama_dense" or meta.adapter != "llama_dense_v1":
        raise ValueError(
            "unsupported manifest adapter: "
            f"family={meta.model_family!r}, adapter={meta.adapter!r}"
        )
    if meta.weight_format not in {"pt", "pytorch"}:
        raise ValueError(
            f"unsupported manifest weight format: {meta.weight_format!r}"
        )
    manifest_attention = meta.extra.get("attn_implementation")
    if manifest_attention is not None and manifest_attention != cfg.attention_implementation:
        raise ValueError(
            "manifest/config mismatch: "
            f"attn_implementation: manifest={manifest_attention!r}, "
            f"config={cfg.attention_implementation!r}"
        )


# ---------------------------------------------------------------------------
# Build pipeline from saved manifest
# ---------------------------------------------------------------------------

def build_pipeline_from_manifest(
    manifest_or_dir: ModelManifest | str | Path,
    *,
    artifact_root: str | Path | None = None,
    devices: list[torch.device] | None = None,
    job_id: str = "local",
    transport: str = "cpu",
    activation_checkpointing: bool = False,
    layer_ranges: Sequence[tuple[int, int]] | None = None,
) -> list:  # list[StageWorker]
    """
    Load a saved MeshGPU model (manifest + shard files) and build a pipeline.

    Args:
        manifest_or_dir: A ModelManifest object, or a path to a directory containing
                         manifest.json (written by import_from_hf).
        artifact_root: Directory containing the config and shard paths when
                       ``manifest_or_dir`` is an in-memory manifest object.
        devices: One device per stage.  Defaults to CPU for all stages.
        job_id: Job identifier embedded in StageContext.

    Returns:
        list[StageWorker] ready for pipeline_prefill / pipeline_decode_step.
    """
    if isinstance(manifest_or_dir, ModelManifest):
        manifest_header = manifest_or_dir
    else:
        manifest_header = ModelManifest.load(Path(manifest_or_dir) / "manifest.json")
    if manifest_header.meta.adapter == "qwen3_hf_v1":
        from meshgpu.artifacts.qwen_import import build_qwen_pipeline_from_manifest

        return build_qwen_pipeline_from_manifest(
            manifest_or_dir,
            artifact_root=artifact_root,
            devices=devices,
            job_id=job_id,
            transport=transport,
            activation_checkpointing=activation_checkpointing,
            layer_ranges=layer_ranges,
        )

    manifest, shard_root, cfg = _load_manifest_context(
        manifest_or_dir,
        artifact_root=artifact_root,
    )
    ordered_shards = validate_manifest_layout(manifest)
    ranges = (
        _validate_requested_ranges(layer_ranges, cfg.num_hidden_layers)
        if layer_ranges is not None
        else [(shard.layer_start, shard.layer_end) for shard in ordered_shards]
    )
    n = len(ranges)
    if devices is None:
        devices = [torch.device("cpu")] * n
    if len(devices) != n:
        raise ValueError(f"need {n} devices for {n} stages, got {len(devices)}")

    if layer_ranges is not None:
        return [
            _build_stage_for_range(
                manifest,
                cfg,
                ordered_shards,
                stage_id,
                layer_range,
                is_last=stage_id == n - 1,
                device=devices[stage_id],
                job_id=job_id,
                artifact_root=shard_root,
                transport=transport,
                activation_checkpointing=activation_checkpointing,
            )
            for stage_id, layer_range in enumerate(ranges)
        ]

    return [
        build_stage_from_manifest(
            manifest,
            stage_idx,
            device=devices[stage_idx],
            job_id=job_id,
            artifact_root=shard_root,
            _validated_cfg=cfg,
            _ordered_shards=ordered_shards,
            transport=transport,
            activation_checkpointing=activation_checkpointing,
        )
        for stage_idx in range(n)
    ]


def build_stage_from_manifest(
    manifest_or_dir: ModelManifest | str | Path,
    stage_id: int,
    *,
    device: torch.device | None = None,
    job_id: str = "local",
    artifact_root: str | Path | None = None,
    _validated_cfg: LlamaConfig | None = None,
    _ordered_shards: list[ShardEntry] | None = None,
    transport: str = "cpu",
    activation_checkpointing: bool = False,
) -> Any:
    """Load exactly one artifact shard without materializing other stages.

    This is the entry point for a stage process or a remote stage endpoint.  A
    full ``build_pipeline_from_manifest`` would otherwise load every shard on
    the endpoint's GPU, defeating model sharding.
    """
    if isinstance(manifest_or_dir, ModelManifest):
        manifest_header = manifest_or_dir
    else:
        header_root = Path(manifest_or_dir)
        manifest_header = ModelManifest.load(header_root / "manifest.json")
    if manifest_header.meta.adapter == "qwen3_hf_v1":
        from meshgpu.artifacts.qwen_import import build_qwen_stage_from_manifest

        return build_qwen_stage_from_manifest(
            manifest_or_dir,
            stage_id,
            device=device,
            job_id=job_id,
            artifact_root=artifact_root,
            transport=transport,
            activation_checkpointing=activation_checkpointing,
        )

    from meshgpu.backends.portable.stage_worker import StageContext, StageWorker
    from meshgpu.models.llama_dense import LlamaStage

    manifest, shard_root, cfg = _load_manifest_context(
        manifest_or_dir,
        artifact_root=artifact_root,
        validated_cfg=_validated_cfg,
    )
    ordered_shards = (
        validate_manifest_layout(manifest)
        if _ordered_shards is None
        else _ordered_shards
    )
    if stage_id < 0 or stage_id >= len(ordered_shards):
        raise IndexError(
            f"stage_id {stage_id} out of range [0, {len(ordered_shards)})"
        )
    if device is None:
        device = torch.device("cpu")
    shard = ordered_shards[stage_id]
    dtype_map = {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }
    try:
        model_dtype = dtype_map[manifest.meta.compute_dtype]
    except KeyError as exc:
        raise ValueError(
            f"unsupported artifact compute_dtype: {manifest.meta.compute_dtype!r}"
        ) from exc

    is_first = stage_id == 0
    is_last = stage_id == len(ordered_shards) - 1
    # Materialize and validate the shard on CPU before moving it to the
    # target GPU.  Loading with ``map_location=device`` while the randomly
    # initialized stage already lives on CUDA creates a second full copy of
    # the shard during ``load_state_dict`` and can OOM a card that would fit
    # the resident model.
    target_device = torch.device(device)
    stage = LlamaStage(
        cfg,
        shard.layer_start,
        shard.layer_end,
        has_embedding=is_first,
        has_lm_head=is_last,
        device=torch.device("cpu"),
        activation_checkpointing=activation_checkpointing,
    ).to(model_dtype)

    shard_file = _resolve_artifact_path(shard_root, shard.path)
    if not shard_file.exists():
        raise FileNotFoundError(f"shard not found: {shard_file}")
    if shard_file.stat().st_size != shard.byte_length:
        raise ValueError(
            f"shard {shard.shard_id} size mismatch: expected {shard.byte_length}, "
            f"got {shard_file.stat().st_size}"
        )
    actual_sha = _sha256_file(shard_file)
    if actual_sha != shard.sha256:
        raise ValueError(
            f"shard {shard.shard_id} hash mismatch: expected {shard.sha256}, "
            f"got {actual_sha}"
        )
    sd = torch.load(shard_file, map_location="cpu", weights_only=True)
    missing, unexpected = stage.load_state_dict(sd, strict=True)
    if missing or unexpected:
        raise RuntimeError(
            f"Stage {stage_id} weight mismatch — missing={missing}, unexpected={unexpected}"
        )
    if target_device.type != "cpu":
        stage = stage.to(target_device)

    ctx = StageContext(
        stage_id=stage_id,
        layer_start=shard.layer_start,
        layer_end=shard.layer_end,
        device=device,
        is_first=is_first,
        is_last=is_last,
        job_id=job_id,
        attempt_id="local",
        transport=transport,
    )
    worker = StageWorker(stage, ctx)
    log.info(
        "Loaded stage %d  layers [%d, %d)  on %s",
        stage_id,
        shard.layer_start,
        shard.layer_end,
        device,
    )
    return worker


def _validate_requested_ranges(
    layer_ranges: Sequence[tuple[int, int]],
    num_layers: int,
) -> list[tuple[int, int]]:
    """Validate a planner-produced contiguous partition before loading it."""
    if isinstance(layer_ranges, (str, bytes)) or len(layer_ranges) == 0:
        raise ValueError("layer_ranges must contain at least one range")
    if len(layer_ranges) > num_layers:
        raise ValueError("layer_ranges cannot contain more stages than model layers")
    result: list[tuple[int, int]] = []
    expected_start = 0
    for index, raw_range in enumerate(layer_ranges):
        if (
            not isinstance(raw_range, (tuple, list))
            or len(raw_range) != 2
            or any(
                isinstance(value, bool) or not isinstance(value, int)
                for value in raw_range
            )
        ):
            raise TypeError(f"layer_ranges[{index}] must be a pair of integers")
        layer_start, layer_end = raw_range
        if (
            layer_start != expected_start
            or layer_end <= layer_start
            or layer_end > num_layers
        ):
            raise ValueError(
                "layer_ranges must be non-empty and contiguous from zero; "
                f"range {index} was [{layer_start}, {layer_end}) after "
                f"{expected_start}"
            )
        result.append((layer_start, layer_end))
        expected_start = layer_end
    if expected_start != num_layers:
        raise ValueError(
            f"layer_ranges cover [0, {expected_start}), expected [0, {num_layers})"
        )
    return result


def _load_verified_shard_state(
    artifact_root: Path,
    shard: ShardEntry,
) -> dict[str, torch.Tensor]:
    """Load one source shard after checking the immutable manifest evidence."""
    shard_file = _resolve_artifact_path(artifact_root, shard.path)
    if not shard_file.exists():
        raise FileNotFoundError(f"shard not found: {shard_file}")
    if shard_file.stat().st_size != shard.byte_length:
        raise ValueError(
            f"shard {shard.shard_id} size mismatch: expected {shard.byte_length}, "
            f"got {shard_file.stat().st_size}"
        )
    actual_sha = _sha256_file(shard_file)
    if actual_sha != shard.sha256:
        raise ValueError(
            f"shard {shard.shard_id} hash mismatch: expected {shard.sha256}, "
            f"got {actual_sha}"
        )
    state = torch.load(shard_file, map_location="cpu", weights_only=True)
    if not isinstance(state, dict) or any(not isinstance(key, str) for key in state):
        raise ValueError(f"shard {shard.shard_id} must contain a string-keyed state dict")
    return state


def _state_for_requested_range(
    manifest: ModelManifest,
    artifact_root: Path,
    layer_start: int,
    layer_end: int,
    *,
    is_first: bool,
    is_last: bool,
) -> dict[str, torch.Tensor]:
    """Combine overlapping compact source shards into one local stage state."""
    stage_state: dict[str, torch.Tensor] = {}
    overlapping = manifest.shards_for_layers(layer_start, layer_end)
    if not overlapping:
        raise ValueError(
            f"no artifact shard overlaps requested range [{layer_start}, {layer_end})"
        )
    for shard in overlapping:
        source_state = _load_verified_shard_state(artifact_root, shard)
        for key, value in source_state.items():
            if key.startswith("layers."):
                parts = key.split(".", 2)
                if len(parts) < 3:
                    raise ValueError(f"invalid layer key in shard {shard.shard_id}: {key!r}")
                try:
                    local_index = int(parts[1])
                except ValueError as exc:
                    raise ValueError(
                        f"invalid local layer index in shard {shard.shard_id}: {key!r}"
                    ) from exc
                absolute_index = shard.layer_start + local_index
                if not layer_start <= absolute_index < layer_end:
                    continue
                target_key = f"layers.{absolute_index - layer_start}.{parts[2]}"
            elif key in {"embed_tokens.weight"}:
                if not is_first:
                    continue
                target_key = key
            elif key in {"norm.weight", "lm_head.weight"}:
                if not is_last:
                    continue
                target_key = key
            else:
                raise ValueError(f"unexpected tensor key in shard {shard.shard_id}: {key!r}")
            if target_key in stage_state:
                raise ValueError(
                    f"duplicate tensor {target_key!r} while combining requested stage"
                )
            stage_state[target_key] = value
    return stage_state


def _build_stage_for_range(
    manifest: ModelManifest,
    cfg: LlamaConfig,
    ordered_shards: list[ShardEntry],
    stage_id: int,
    layer_range: tuple[int, int],
    *,
    is_last: bool,
    device: torch.device,
    job_id: str,
    artifact_root: Path,
    transport: str,
    activation_checkpointing: bool,
) -> Any:
    """Build a Llama stage from one planner-selected range."""
    from meshgpu.backends.portable.stage_worker import StageContext, StageWorker

    layer_start, layer_end = layer_range
    is_first = stage_id == 0
    dtype_map = {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }
    try:
        model_dtype = dtype_map[manifest.meta.compute_dtype]
    except KeyError as exc:
        raise ValueError(
            f"unsupported artifact compute_dtype: {manifest.meta.compute_dtype!r}"
        ) from exc
    target_device = torch.device(device)
    stage = LlamaStage(
        cfg,
        layer_start,
        layer_end,
        has_embedding=is_first,
        has_lm_head=is_last,
        device=torch.device("cpu"),
        activation_checkpointing=activation_checkpointing,
    ).to(model_dtype)
    state = _state_for_requested_range(
        manifest,
        artifact_root,
        layer_start,
        layer_end,
        is_first=is_first,
        is_last=is_last,
    )
    missing, unexpected = stage.load_state_dict(state, strict=True)
    if missing or unexpected:
        raise RuntimeError(
            f"Stage {stage_id} weight mismatch — missing={missing}, unexpected={unexpected}"
        )
    if target_device.type != "cpu":
        stage = stage.to(target_device)
    ctx = StageContext(
        stage_id=stage_id,
        layer_start=layer_start,
        layer_end=layer_end,
        device=device,
        is_first=is_first,
        is_last=is_last,
        job_id=job_id,
        attempt_id="local",
        transport=transport,
    )
    log.info(
        "Loaded planned stage %d  layers [%d, %d)  on %s from overlapping shards",
        stage_id,
        layer_start,
        layer_end,
        device,
    )
    return StageWorker(stage, ctx)


def _load_manifest_context(
    manifest_or_dir: ModelManifest | str | Path,
    *,
    artifact_root: str | Path | None = None,
    validated_cfg: LlamaConfig | None = None,
) -> tuple[ModelManifest, Path, LlamaConfig]:
    if isinstance(manifest_or_dir, ModelManifest):
        manifest = manifest_or_dir
        shard_root = Path(artifact_root) if artifact_root is not None else Path(".")
        cfg = validated_cfg or load_llama_config(
            manifest,
            artifact_root=shard_root,
        )
    else:
        shard_root = Path(manifest_or_dir)
        manifest = ModelManifest.load(shard_root / "manifest.json")
        cfg = validated_cfg or load_llama_config(shard_root)
    if manifest.config_hash:
        actual_config_hash = ModelManifest.compute_config_hash(dataclasses.asdict(cfg))
        if actual_config_hash != manifest.config_hash:
            raise ValueError(
                "artifact config hash mismatch: the referenced config does not match "
                f"manifest (expected {manifest.config_hash}, got {actual_config_hash})"
            )
    validate_manifest_config(manifest, cfg)
    return manifest, shard_root, cfg


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(_CHUNK):
            h.update(chunk)
    return h.hexdigest()


def _validate_stage_state(
    cfg: LlamaConfig,
    state: dict[str, torch.Tensor],
    *,
    layer_start: int,
    layer_end: int,
    is_first: bool,
    is_last: bool,
    stage_idx: int,
) -> None:
    """Validate an extracted shard before it becomes part of a manifest."""
    expected = LlamaStage(
        cfg,
        layer_start,
        layer_end,
        has_embedding=is_first,
        has_lm_head=is_last,
    ).state_dict()
    missing = sorted(set(expected) - set(state))
    unexpected = sorted(set(state) - set(expected))
    shape_errors = [
        f"{key}: expected {tuple(expected[key].shape)}, got {tuple(state[key].shape)}"
        for key in sorted(set(expected).intersection(state))
        if tuple(expected[key].shape) != tuple(state[key].shape)
    ]
    if missing or unexpected or shape_errors:
        details = []
        if missing:
            details.append(f"missing={missing}")
        if unexpected:
            details.append(f"unexpected={unexpected}")
        if shape_errors:
            details.append(f"shape_errors={shape_errors}")
        raise ValueError(f"stage {stage_idx} weight schema mismatch: " + ", ".join(details))


def _atomic_write_text(path: Path, contents: str) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_text(contents)
        with temporary.open("rb") as written:
            os.fsync(written.fileno())
        os.replace(temporary, path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _atomic_torch_save(state: dict[str, torch.Tensor], path: Path) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        torch.save(state, temporary)
        with temporary.open("rb") as written:
            os.fsync(written.fileno())
        os.replace(temporary, path)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _save_tokenizer_atomic(tokenizer: Any, destination: Path) -> None:
    """Save a tokenizer under a new revision without touching older output."""
    temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
    try:
        tokenizer.save_pretrained(temporary)
        os.replace(temporary, destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        raise


def _resolve_artifact_path(root: Path, relative_path: str) -> Path:
    """Resolve a manifest path while keeping it inside the artifact root."""
    candidate = Path(relative_path)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError(f"manifest path must be relative and contained: {relative_path!r}")
    root = root.resolve()
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"manifest path escapes artifact root: {relative_path!r}") from exc
    return resolved
